package embedb

// EmbeDB
// Tags
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sort"

//import "log"

//import "time"

// NewTags - create a new Tags-struct
func NewTags() *Tags {
	t := &Tags{subTags: make(map[string]*SubTag), tagsCounts: make(map[string]int)}
	t.AddTag("test")
	return t
}

// В индексе map[имя_тега]id(current)
type Tags struct {
	sync.Mutex
	subTags    map[string]*SubTag
	tagsCounts map[string]int
}

//func (t *Tags) SelectById(id string) int {
//}

func (t *Tags) SelectByTags(tagsNames []string) []int {
	if len(tagsNames) == 0 {
		return nil
	} else if len(tagsNames) == 1 {
		return t.subTags[tagsNames[0]].list
	}
	//tStart := time.Now().UnixNano()
	tagsCounts2 := make([]int, len(tagsNames))
	for i, tag := range tagsNames {
		if st, ok := t.subTags[tag]; ok {
			//log.Print("...::: ", int(uint64(len(st.arr))<<32))
			tagsCounts2[i] = int(uint64(len(st.arr))<<32) + i
		} else { // тут можно сделать выход по ошибке!
			//tagsCounts2[i] = 2147483647
		}
	}

	//log.Print("tagsCounts2: ", tagsCounts2)
	sort.Sort(sort.IntSlice(tagsCounts2))
	//log.Print("tagsCounts2: ", tagsCounts2)

	tagsOrdered := make([]string, len(tagsCounts2))

	for i, tag := range tagsCounts2 {
		n := int(uint32(tag))
		tagsOrdered[i] = tagsNames[n]
	}
	//log.Print("tagsCounts2: ", tagsOrdered2)
	outList := t.subTags[tagsOrdered[0]].list
	cnt := len(outList)

	//log.Print("...теги под поиск: ", tagsOrdered2)
	//counterTotalCicle := 0

	for i := 1; i < len(tagsOrdered); i++ {
		outList, cnt = t.subTags[tagsOrdered[i]].GetCross(outList)
		if cnt == 0 {
			return outList
		}
	}
	return outList[:cnt]
	/*
		//log.Print("...при поиске сделано итераций: ", counterTotalCicle)
		//tStart2 := time.Now().UnixNano()
		//log.Print("...в тегах прокопались: ", tStart2-tStart)
	*/
}

func (t *Tags) AddTag(tagName string) bool {
	t.Lock()

	if _, ok := t.subTags[tagName]; ok {
		t.Unlock()
		return false
	} else {
		t.subTags[tagName] = NewSubTag()
	}
	t.Unlock()
	return true
}

func (t *Tags) AddToTags(tagsNames []string, id int) bool {
	t.Lock()
	for _, tag := range tagsNames {
		if _, ok := t.subTags[tag]; !ok {
			t.subTags[tag] = NewSubTag()
		}

	}
	t.Unlock()
	for _, tag := range tagsNames {
		t.subTags[tag].Add(id)
	}
	return true
}

func (t *Tags) DelFromTags(tagsNames []string, id int) bool {
	for _, tag := range tagsNames {
		if t, ok := t.subTags[tag]; ok {
			t.Del(id)
		}
	}
	return true
}

/*
func (t *Tags) SortUp(m map[string]int) []string { // сортировка
	n := map[int][]string{}
	var a []int
	out := make([]string, len(m))
	for k, v := range m {
		n[v] = append(n[v], k)
	}
	for k := range n {
		a = append(a, k)
	}
	//sort.Sort(sort.Reverse(sort.IntSlice(a)))
	sort.Sort(sort.IntSlice(a))
	i := 0
	for _, k := range a {
		for _, s := range n[k] {
			out[i] = s
			i++
		}
	}
	return out
}
*/
func NewSubTag() *SubTag {
	return &SubTag{arr: make(map[int]bool), list: make([]int, 0, 100), blum: &Blum{}}
}

// SubTag - хранилище субтегов (секций)
type SubTag struct {
	sync.Mutex
	count int
	arr   map[int]bool
	list  []int
	blum  *Blum
}

func (s *SubTag) Add(id int) bool {
	s.Lock()
	if _, ok := s.arr[id]; ok {
		s.Unlock()
		return false
	}
	s.arr[id] = true
	s.list = append(s.list, id)
	s.blum.Add(id)

	s.count++
	s.Unlock()
	return true
}

func (s *SubTag) Del(id int) bool {
	s.Lock()
	if _, ok := s.arr[id]; !ok {
		s.Unlock()
		return false
	}
	// delete from map
	delete(s.arr, id)
	// delete from list
	i := 0
	for _, k := range s.list {
		if k != id {
			s.list[i] = k
		}
	}
	s.list = s.list[:i]
	// delete from blum
	// ? no del!

	s.Unlock()
	return true
}

func (s *SubTag) GetCross(outList []int) ([]int, int) {
	cnt := 0
	var k int
	s.Lock()
	for u := 0; u < len(outList); u++ {
		k = outList[u]
		if s.blum.Check(k) {
			if _, ok := s.arr[k]; ok {
				outList[cnt] = k
				cnt++
			}
		}
	}
	s.Unlock()
	return outList, cnt
}

type Blum [65536]uint8

func (b *Blum) Add(id int) {
	//uid := uint64(id)
	key := uint16(uint64(id))
	hash := b[key]
	shift := (uint64(id) << 45) >> 61
	in := uint8(1) << shift
	hash = hash | in
	b[key] = hash
}

func (b *Blum) Check(id int) bool {
	key := uint16(uint64(id))
	hash := b[key]
	shift := (uint64(id) << 45) >> 61
	in := uint8(1) << shift
	if in == hash&in {
		return true
	}
	return false
}

type Blum2 [65536]bool

func (b *Blum2) Add(id int) {
	//uid := uint64(id)
	key := uint16(id)
	//log.Print(" _ # _ ", key)
	b[key] = true
}

func (b *Blum2) Check(id int) bool {
	key := uint16(id)
	//log.Print(" _ @ _ ", key, b[key])
	return b[key]
}

type Pair struct {
	Key   string
	Value int
}

type PairList []Pair

type IntSlice []int

func (p IntSlice) Len() int           { return len(p) }
func (p IntSlice) Less(i, j int) bool { return p[i] > p[j] }
func (p IntSlice) Swap(i, j int)      { p[i], p[j] = p[j], p[i] }

// Sort is a convenience method.
func (p IntSlice) Sort() { sort.Sort(p) }
