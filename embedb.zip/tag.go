package embedb

// EmbeDB
// Tags
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sort"

//import "log"

//import "time"

// NewTags - create a new Tags-struct
func NewTags() *Tags {
	t := &Tags{subTags: make(map[string]*SubTag), tagsCounts: make(map[string]int)}
	return t
}

// В индексе map[имя_тега]id(current)
type Tags struct {
	sync.Mutex
	subTags    map[string]*SubTag
	tagsCounts map[string]int
}

func (t *Tags) SelectByTags(tagsNames []string, sortKey string) []int {
	if len(tagsNames) == 0 {
		return nil
	} else if len(tagsNames) == 1 {
		return t.subTags[tagsNames[0]].lists[""]
	}
	//tStart := time.Now().UnixNano()
	tagsCounts2 := make([]int, len(tagsNames))
	for i, tag := range tagsNames {
		if st, ok := t.subTags[tag]; ok {
			//log.Print("...::: ", int(uint64(len(st.arr))<<32))
			tagsCounts2[i] = int(uint64(len(st.arr))<<32) + i
		} else { // тут можно сделать выход по ошибке!
			//tagsCounts2[i] = 2147483647
		}
	}
	sort.Sort(sort.IntSlice(tagsCounts2))
	tagsOrdered := make([]string, len(tagsCounts2))

	for i, tag := range tagsCounts2 {
		n := int(uint32(tag))
		tagsOrdered[i] = tagsNames[n]
	}
	var outList []int
	if arr, ok := t.subTags[tagsOrdered[0]].lists[sortKey]; ok {
		outList = arr
	} else {
		outList = t.subTags[tagsOrdered[0]].lists[""]
	}
	cnt := len(outList)

	//log.Print("...теги под поиск: ", tagsOrdered2)
	//counterTotalCicle := 0

	for i := 1; i < len(tagsOrdered); i++ {
		outList, cnt = t.subTags[tagsOrdered[i]].GetCross(outList)
		if cnt == 0 {
			break //return outList[:cnt]
		}
	}
	return outList[:cnt]
	/*
		//log.Print("...при поиске сделано итераций: ", counterTotalCicle)
		//tStart2 := time.Now().UnixNano()
		//log.Print("...в тегах прокопались: ", tStart2-tStart)
	*/
}

func (t *Tags) AddToTags(tagsNames []string, id int, values map[string]int) bool {
	t.Lock()
	for _, tag := range tagsNames {
		if _, ok := t.subTags[tag]; !ok {
			t.subTags[tag] = NewSubTag(values)
		}

	}
	t.Unlock()
	for _, tag := range tagsNames {
		t.subTags[tag].Add(id, values)
	}

	return true
}

func NewSubTag(ords map[string]int) *SubTag {
	//log.Print("Субтег получил список ords: ", ords)
	s := &SubTag{
		arr:   make(map[int]bool),
		lists: make(map[string][]int),
		blum:  &Blum{},
	}
	for k, _ := range ords {
		s.lists[k] = make([]int, 0, 100)
	}
	s.lists[""] = make([]int, 0, 100)
	return s
}

// SubTag - хранилище субтегов (секций)
type SubTag struct {
	sync.Mutex
	count int
	arr   map[int]bool
	lists map[string][]int
	blum  *Blum
}

func (s *SubTag) Add(id int, values map[string]int) bool {
	s.Lock()
	if _, ok := s.arr[id]; ok {
		s.Unlock()
		return false
	}
	s.arr[id] = true
	s.blum.Add(id)
	// в v значения по которым сортировать
	for k, v := range values {
		v2 := int(uint64(uint32(int32(v)))<<32 + uint64(uint32(id)))
		if arr, ok := s.lists[k]; ok {
			if len(arr) == 0 {
				s.lists[k] = append(s.lists[k], v2)
				continue
			}
			flag := true
			ln := len(arr)
			average := arr[0] / 2
			average += arr[ln-1] / 2
			if v2 > average {
				for i := ln - 1; i < 0; i-- {
					if arr[i] < v2 {
						arr = append(arr[:i], append([]int{v2}, arr[i:]...)...)
						flag = false
						break
					}
				}
			} else {
				for x, y := range arr {
					if y < v2 {
						arr = append(arr[:x], append([]int{v2}, arr[x:]...)...)
						flag = false
						break
					}
				}
			}

			if flag {
				arr = append(arr, v2)
			}
			s.lists[k] = arr
		}
	}
	s.lists[""] = append(s.lists[""], id)

	s.count++
	s.Unlock()
	//log.Print("result Add: ", s.lists)
	return true
}

func (s *SubTag) GetCross(outList []int) ([]int, int) {
	cnt := 0
	var k int
	s.Lock()
	for u := 0; u < len(outList); u++ {
		k = int(uint32(outList[u])) // берём только правую часть цифры! она - номер, а левая - это значение по которому сортировали
		//if 4294967295 < k {
		//	panic(k)
		//}

		if s.blum.Check(k) {
			if _, ok := s.arr[k]; ok {
				outList[cnt] = k
				cnt++
			}
		}
	}
	s.Unlock()
	return outList, cnt
}

type Blum [65536]uint8

func (b *Blum) Add(id int) {
	//uid := uint64(id)
	key := uint16(uint64(id))
	hash := b[key]
	shift := (uint64(id) << 45) >> 61
	in := uint8(1) << shift
	hash = hash | in
	b[key] = hash
}

func (b *Blum) Check(id int) bool {
	key := uint16(uint64(id))
	hash := b[key]
	shift := (uint64(id) << 45) >> 61
	in := uint8(1) << shift
	if in == hash&in {
		return true
	}
	return false
}
