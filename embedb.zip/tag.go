package embedb

// EmbeDB
// Tags
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sort"

import "log"

// NewTags - create a new Tags-struct
func NewTags() *Tags {
	t := &Tags{subTags: make(map[string]*SubTag)}
	t.AddTag("test")
	return t
}

// В индексе map[имя_тега]id(current)
type Tags struct {
	sync.Mutex
	subTags map[string]*SubTag
}

func (t *Tags) SelectByTags(tagsNames []string) map[uint64]bool {
	tagsCounts := make(map[string]int)
	for _, tagName := range tagsNames {
		tagsCounts[tagName] = t.subTags[tagName].count
	}
	tagsOrdered := t.SortUp(tagsCounts)
	outList := t.subTags[tagsOrdered[0]].arr
	//log.Print("_____", len(tagsOrdered), tagsOrdered, tagsNames)

	for i := 1; i < len(tagsOrdered); i++ {
		//cSubTag := t.subTags[tagsOrdered[i]].arr
		nList := make(map[uint64]bool)
		for k, _ := range outList {
			if _, ok := t.subTags[tagsOrdered[i]].arr[k]; ok {
				nList[k] = true
			}
		}
		log.Print(len(outList), "$$$$$$$$$$$", len(nList), "&&&&&&", len(t.subTags[tagsOrdered[i]].arr))
		outList = nList
		if len(nList) == 0 {
			break
		}
	}
	return outList
}

func (t *Tags) AddTag(tagName string) bool {
	t.Lock()

	if _, ok := t.subTags[tagName]; ok {
		t.Unlock()
		return false
	} else {
		t.subTags[tagName] = NewSubTag()
	}
	t.Unlock()
	return true
}

func (t *Tags) AddToTags(tagsNames []string, id uint64) bool {
	for _, tag := range tagsNames {
		if _, ok := t.subTags[tag]; !ok {
			return false
		}
	}
	for _, tag := range tagsNames {
		t.subTags[tag].Add(id)
	}
	return true
}

func (t *Tags) SortUp(m map[string]int) []string { // сортировка
	n := map[int][]string{}
	var a []int
	out := make([]string, len(m))
	for k, v := range m {
		n[v] = append(n[v], k)
	}
	for k := range n {
		a = append(a, k)
	}
	//sort.Sort(sort.Reverse(sort.IntSlice(a)))
	sort.Sort(sort.IntSlice(a))
	i := 0
	for _, k := range a {
		for _, s := range n[k] {
			out[i] = s
			i++
		}
	}
	return out
}

func NewSubTag() *SubTag {
	return &SubTag{arr: make(map[uint64]bool)}
}

// SubTag - хранилище субтэгов (секций)
type SubTag struct {
	sync.Mutex
	count int
	arr   map[uint64]bool
}

func (s *SubTag) Add(id uint64) bool {
	s.Lock()
	if _, ok := s.arr[id]; ok {
		s.Unlock()
		return false
	}
	s.arr[id] = true
	s.count++
	s.Unlock()
	return true
}

type Pair struct {
	Key   string
	Value int
}

type PairList []Pair
