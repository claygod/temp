package embedb

// EmbeDB
// Tags
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sort"

//import "log"

//import "time"

// NewTags - create a new Tags-struct
func NewTags() *Tags {
	t := &Tags{subTags: make(map[string]*SubTag), tagsCounts: make(map[string]int)}
	t.AddTag("test")
	return t
}

// В индексе map[имя_тега]id(current)
type Tags struct {
	sync.Mutex
	subTags    map[string]*SubTag
	tagsCounts map[string]int
}

func (t *Tags) SelectByTags(tagsNames []string) []int { //  //  map[uint64]bool
	tagsCounts2 := make([]int, len(tagsNames))
	//n:=0
	for i, tag := range tagsNames {
		if st, ok := t.subTags[tag]; ok {
			tagsCounts2[i] = int(uint64(len(st.arr))<<32) + i
		} else { // тут можно сделать выход по ошибке!
			//tagsCounts2[i] = 2147483647
		}
	}

	//log.Print("tagsCounts2: ", tagsCounts2)
	sort.Sort(sort.IntSlice(tagsCounts2))
	//log.Print("tagsCounts2: ", tagsCounts2)

	tagsOrdered2 := make([]string, len(tagsCounts2))

	for i, tag := range tagsCounts2 {
		n := int(uint32(tag))
		tagsOrdered2[i] = tagsNames[n]
	}

	outList := t.subTags[tagsOrdered2[0]].arr
	//t.Lock()
	for i := 1; i < len(tagsOrdered2); i++ {
		t.subTags[tagsOrdered2[i]].Lock()
		// nList := make(map[int]bool)
		for k, _ := range outList {
			//if _, ok := t.subTags[tagsOrdered2[i]].arr[k]; ok {
			//	nList[k] = true
			//}
			if _, ok := t.subTags[tagsOrdered2[i]].arr[k]; !ok {
				delete(outList, k)
			}
		}
		t.subTags[tagsOrdered2[i]].Unlock()
		if len(outList) == 0 {
			break
		}
	}
	//t.Unlock()
	outList2 := make([]int, len(outList))
	n := 0
	for v, _ := range outList {
		outList2[n] = int(v)
		n++
	}

	sort.Sort(IntSlice(outList2))
	//sort.Sort(sort.IntSlice(outList2))
	//sort.Sort(sort.Reverse(sort.IntSlice(outList2)))
	//return []int{1}
	return outList2
}

func (t *Tags) AddTag(tagName string) bool {
	t.Lock()

	if _, ok := t.subTags[tagName]; ok {
		t.Unlock()
		return false
	} else {
		t.subTags[tagName] = NewSubTag()
	}
	t.Unlock()
	return true
}

func (t *Tags) AddToTags(tagsNames []string, id int) bool {
	for _, tag := range tagsNames {
		t.Lock()
		if _, ok := t.subTags[tag]; !ok {

			t.subTags[tag] = NewSubTag()

		}
		t.Unlock()
	}
	for _, tag := range tagsNames {
		t.subTags[tag].Add(id)
	}
	return true
}

/*
func (t *Tags) SortUp(m map[string]int) []string { // сортировка
	n := map[int][]string{}
	var a []int
	out := make([]string, len(m))
	for k, v := range m {
		n[v] = append(n[v], k)
	}
	for k := range n {
		a = append(a, k)
	}
	//sort.Sort(sort.Reverse(sort.IntSlice(a)))
	sort.Sort(sort.IntSlice(a))
	i := 0
	for _, k := range a {
		for _, s := range n[k] {
			out[i] = s
			i++
		}
	}
	return out
}
*/
func NewSubTag() *SubTag {
	return &SubTag{arr: make(map[int]bool)}
}

// SubTag - хранилище субтэгов (секций)
type SubTag struct {
	sync.Mutex
	count int
	arr   map[int]bool
}

func (s *SubTag) Add(id int) bool {
	s.Lock()
	if _, ok := s.arr[id]; ok {
		s.Unlock()
		return false
	}
	s.arr[id] = true
	s.count++
	s.Unlock()
	return true
}

type Pair struct {
	Key   string
	Value int
}

type PairList []Pair

type IntSlice []int

func (p IntSlice) Len() int           { return len(p) }
func (p IntSlice) Less(i, j int) bool { return p[i] > p[j] }
func (p IntSlice) Swap(i, j int)      { p[i], p[j] = p[j], p[i] }

// Sort is a convenience method.
func (p IntSlice) Sort() { sort.Sort(p) }
