package embedb

// EmbeDB
// Engine
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

//import "log"

//import "time"

//import "unsafe"
//import "strconv"

// POOL_DEGREE - degree of defining the size of the pool (8 to 16)
//const POOL_DEGREE uint64 = 4

// POOL_SIZE - calculated as the number of degree, not to change!
//const POOL_SIZE uint64 = uint64(uint64(1) << POOL_DEGREE)

//const SECTION_SIZE uint64 = 6100
//const SECTION_LIMIT uint64 = 6000
const TRIAL_LIMIT int = 20000000

//
const (
	ASC = iota
	DESC
)

// New - create a new EmbeDb-struct
func New(item interface{}, id string, tags []string) (*EmbeDb, error) {
	//sId := "Id"
	//sTags := []string{"Title", "Date", "Tags"}
	spec, err := NewSpec(item, id, tags)
	if err != nil {
		return nil, err
	}
	e := &EmbeDb{
		//id: NewIdPool(),
		//sect:    NewSectPool(),
		tags:    NewTags(),
		spec:    spec,
		storage: NewStorage(), // NewStorage(),
		index:   NewIndex(),
		sorter:  NewSorter(spec),
	}
	// Тестирование !!
	//for i := 0; i < 256; i++ {
	//	e.tags.AddTag(strconv.Itoa(i))
	//}
	return e, nil
}

// EmbeDb
type EmbeDb struct {
	//id *IdPool
	//sect    *SectPool
	tags    *Tags
	spec    *Spec
	storage *Storage //Storage
	index   *Index
	sorter  *Sorter
}

func (e *EmbeDb) Add(item interface{}) error {
	//log.Print("Теги от spec: ", e.spec.GetTags(item))
	//itmX := item.(Article)
	id := e.spec.GetId(item)
	//key := Hash64a([]byte(id))
	k := e.storage.Add(item)
	e.index.Add(id, k)
	tgs := e.spec.GetTags(item) // itmX.Tags
	e.tags.AddToTags(tgs, k)
	return nil
}

func (e *EmbeDb) Del(id string) error {
	num := e.index.GetNum(id)
	item := e.storage.Get(num)
	tags := e.spec.GetTags(item)
	e.tags.DelFromTags(tags, num)
	e.index.Del(id)
	return nil
}

func (e *EmbeDb) Get(id string) interface{} {
	num := e.index.GetNum(id)
	item := e.storage.Get(num)
	tags := e.spec.GetTags(item)
	e.tags.DelFromTags(tags, num)
	e.index.Del(id)

	if num := e.index.GetNum(id); num >= 0 {
		return e.storage.Get(num)
	}
	return nil
}

/*
func (e *EmbeDb) Select(tagsNames []string) []interface{} {
	//log.Print("COUNT SELECTED:", len(e.tags.SelectByTags(tagsNames)))
	//log.Print("SELECTED:", e.tags.SelectByTags(tagsNames))
	log.Print("LISTED:", e.storage.List(e.tags.SelectByTags(tagsNames)))
	return e.storage.List(e.tags.SelectByTags(tagsNames))
}
*/
func (e *EmbeDb) Select() *Query {
	return newQuery(e)
}

func (e *EmbeDb) selectDo(q *Query) []interface{} {
	//tStart := time.Now().UnixNano()
	if len(q.fields) == 0 {
		return make([]interface{}, 0)
	}
	//return e.limit(e.sort(e.where(q.fields, 0, 11111111), q.sort, q.from, q.to), q.from, q.to)
	//w := e.where(q.fields, 0, 11111111)
	//log.Print("Step selectDo WHeRE ", time.Now().UnixNano()-tStart)
	//tStart = time.Now().UnixNano()
	//return w //e.sort(w, q.sort, q.from, q.to)
	if len(q.sort) != 0 {
		return e.sort(e.where(q.fields), q.sort, q.from, q.to)
	}
	return e.limitItems(e.where(q.fields, q.from, q.to), q.from, q.to)
}

func (e *EmbeDb) where(w []string, limits ...int) []interface{} {
	if len(limits) == 2 {
		return e.storage.List(e.limitIds(e.tags.SelectByTags(w), limits[0], limits[1]))
	}
	return e.storage.List(e.tags.SelectByTags(w))
}

func (e *EmbeDb) sort(items []interface{}, s map[string]int, from int, to int) []interface{} {
	for tag, asc := range s {
		return e.sorter.SortItems(items, tag, asc, from, to) // e.spec.Sort(items, k, v)
	}
	return nil
}

func (e *EmbeDb) limitIds(tags []int, from int, to int) []int {
	if to > len(tags) {
		to = len(tags)
	}
	if from > len(tags) {
		from = len(tags)
	}
	//out := tags[from:to]
	return tags[from:to] //out
}

func (e *EmbeDb) limitItems(items []interface{}, from int, to int) []interface{} {
	if to > len(items) {
		to = len(items)
	}
	if from > len(items) {
		from = len(items)
	}
	//out := items[from:to]
	return items[from:to]
}

// Implements FNV-1a, non-cryptographic hash function
// created by Glenn Fowler, Landon Curt Noll and Phong Vo.
func Hash64a(data []byte) uint64 {
	var offset64 uint64 = 14695981039346656037
	var prime64 uint64 = 1099511628211
	var hash uint64 = offset64
	for _, c := range data {
		hash ^= uint64(c)
		hash *= prime64
	}
	return hash
}

func GetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

type Test struct {
	A1 string
	A2 string
}

// newQuery - create a new Query-struct
func newQuery(db *EmbeDb) *Query {
	return &Query{
		db:     db,
		fields: make([]string, 0, 10),
		sort:   make(map[string]int),
		from:   0,
		to:     100,
	}
}

type Query struct {
	db     *EmbeDb
	fields []string
	sort   map[string]int
	from   int
	to     int
}

func (q *Query) ByFields(where []string) *Query {
	q.fields = where
	return q
}

func (q *Query) OrderBy(tag string, asc int) *Query {
	q.sort[tag] = asc
	return q
}

func (q *Query) Limit(from int, to int) *Query {
	q.from = from
	q.to = to
	return q
}
func (q *Query) Do() []interface{} {
	return q.db.selectDo(q)
}

type List []interface{}

func (l *List) Limit(args ...int) []interface{} {

	return nil
}
