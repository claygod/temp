package embedb

// EmbeDB
// Engine
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

//import "log"
import "errors"

//import "time"

//import "unsafe"
//import "strconv"

// POOL_DEGREE - degree of defining the size of the pool (8 to 16)
//const POOL_DEGREE uint64 = 4

// POOL_SIZE - calculated as the number of degree, not to change!
//const POOL_SIZE uint64 = uint64(uint64(1) << POOL_DEGREE)

//const SECTION_SIZE uint64 = 6100
//const SECTION_LIMIT uint64 = 6000
const TRIAL_LIMIT int = 20000000

//
const (
	ASC = iota
	DESC
)

// New - create a new EmbeDb-struct
func New(item interface{}, id string, tags []string) (*EmbeDb, error) {
	//sId := "Id"
	//sTags := []string{"Title", "Date", "Tags"}
	spec, err := NewSpec(item, id, tags)
	sortIndexes := spec.GetSortIndexes(item)
	if err != nil {
		return nil, err
	}
	e := &EmbeDb{
		tags:    NewTags(sortIndexes),
		spec:    spec,
		storage: NewStorage(),
		index:   NewIndex(),
		//sorter:  NewSorter(spec),
	}
	return e, nil
}

// EmbeDb
type EmbeDb struct {
	tags    *Tags
	spec    *Spec
	storage *Storage
	index   *Index
	//sorter  *Sorter
}

func (e *EmbeDb) Add(item interface{}) error {
	//
	//itmX := item.(Article)
	id := e.spec.GetId(item)
	//key := Hash64a([]byte(id))
	k := e.storage.Add(item)
	e.index.Add(id, k)
	tgs := e.spec.GetTags(item) // itmX.Tags

	e.tags.AddToTags(tgs, k)
	//log.Print("Заглянем внутрь тегов ", e.tags.subTags["TagsNews"].lists)
	return nil
}

func (e *EmbeDb) Update(itemNew interface{}) error {
	id := e.spec.GetId(itemNew)
	num := e.index.GetNum(id)
	if num < 0 {
		return errors.New("Запись, которую вы хотите переnисать не существует!")
	}
	itemOld := e.storage.Get(num)
	tagsOld := e.spec.GetTags(itemOld)
	tagsNew := e.spec.GetTags(itemNew)
	// из списка делаем массив
	arrNew := make(map[string]bool)
	for _, tag := range tagsNew {
		arrNew[tag] = true
	}
	// формируем список на удаление
	listDel := make([]string, 0)
	for _, tag := range tagsOld {
		if _, ok := arrNew[tag]; ok {
			delete(arrNew, tag)
		} else {
			listDel = append(listDel, tag)
		}
	}
	// формируем список новых тегов
	listAdd := make([]string, 0)
	for tag, _ := range arrNew {
		listAdd = append(listAdd, tag)
	}
	// удаляем старые теги
	e.tags.DelFromTags(listDel, num)

	// меняем item
	e.storage.Update(itemNew, num)

	// добавляем новые теги
	e.tags.AddToTags(listAdd, num)

	return nil
}

func (e *EmbeDb) Del(id string) error {
	num := e.index.GetNum(id)
	//log.Print("- для удаления найден NUM - ", num, " ", e.index.arr)
	item := e.storage.Get(num)
	//log.Print("- для удаления найден ITEM - ", item, " ", e.storage.arr)
	if item == nil {
		return errors.New("Такой записи нет!")
	}
	//log.Print("- для удаления найден - ", item)
	tags := e.spec.GetTags(item) // !!!
	//log.Print("- для удаления найден TAGS- ", tags, " ", e.index.arr)
	e.tags.DelFromTags(tags, num)
	e.index.Del(id)
	return nil
}

/*
func (e *EmbeDb) Get(id string) interface{} {
	num := e.index.GetNum(id)
	item := e.storage.Get(num)
	tags, _ := e.spec.GetTags(item)
	e.tags.DelFromTags(tags, num)
	e.index.Del(id)

	if num := e.index.GetNum(id); num >= 0 {
		return e.storage.Get(num)
	}
	return nil
}
*/

func (e *EmbeDb) Select() *Query {
	return newQuery(e)
}

func (e *EmbeDb) selectDo(q *Query) []interface{} {
	//tStart := time.Now().UnixNano()
	if len(q.fields) == 0 {
		return make([]interface{}, 0)
	}
	return e.storage.List(e.limitIds(e.tags.SelectByTags(q.fields, q.sort), q.from, q.how, q.asc), q.asc)

}

func (e *EmbeDb) limitIds(tags []int, from int, how int, asc int) []int {
	//log.Print("limitIds получил: ", tags)
	ln := len(tags)
	if how < 1 || from < 0 || from >= ln { //
		return []int{}
	}

	if asc == ASC {
		to := from + how
		if to > ln {
			to = ln
		}
		if from > ln {
			from = ln
		}
		//log.Print("limitIds отдал ASC: ", tags[from:to])
		return tags[from:to]
	} else {

		from2 := ln - from - how
		if from2 > ln {
			from2 = ln
		} else if from2 < 0 {
			from2 = 0
		}
		to := ln - from
		if to > ln {
			to = ln
		}
		//log.Print("limitIds отдал DESC: ", tags[from2:to])
		return tags[from2:to]
	}

}

func (e *EmbeDb) limitItems(items []interface{}, from int, how int) []interface{} {
	if how > len(items) {
		how = len(items)
	}
	if from > len(items) {
		from = len(items)
	}
	return items[from:how]
}

// newQuery - create a new Query-struct
func newQuery(db *EmbeDb) *Query {
	return &Query{
		db:     db,
		fields: make([]string, 0, 10),
		sort:   "",
		asc:    0,
		from:   0,
		how:    17,
	}
}

type Query struct {
	db     *EmbeDb
	fields []string
	sort   string
	asc    int
	from   int
	how    int
}

func (q *Query) ByFields(where []string) *Query {
	q.fields = where
	return q
}

func (q *Query) OrderBy(tag string, asc int) *Query {
	q.sort = tag
	q.asc = asc
	return q
}

func (q *Query) Limit(from int, how int) *Query {
	q.from = from
	q.how = how
	return q
}
func (q *Query) Do() []interface{} {
	return q.db.selectDo(q)
}
