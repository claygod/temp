package embedb

// EmbeDB
// Engine
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "log"
import "unsafe"
import "strconv"

// POOL_DEGREE - degree of defining the size of the pool (8 to 16)
const POOL_DEGREE uint64 = 16

// POOL_SIZE - calculated as the number of degree, not to change!
const POOL_SIZE uint64 = uint64(uint64(1) << POOL_DEGREE)

//const SECTION_SIZE uint64 = 6100
//const SECTION_LIMIT uint64 = 6000
const TRIAL_LIMIT int = 20000000

// New - create a new EmbeDb-struct
func New(item interface{}) (*EmbeDb, error) {
	sId := "Id"
	sTags := []string{"Title", "Tags"}
	spec, err := NewSpec(item, sId, sTags)
	if err != nil {
		return nil, err
	}
	e := &EmbeDb{
		id:      NewIdPool(),
		sect:    NewSectPool(),
		tags:    NewTags(),
		spec:    spec,
		storage: NewStorage(),
		index:   NewIndex(),
	}
	// Тестирование !!
	for i := 0; i < 256; i++ {
		e.tags.AddTag(strconv.Itoa(i))
	}
	return e, nil
}

// EmbeDb
type EmbeDb struct {
	id      *IdPool
	sect    *SectPool
	tags    *Tags
	spec    *Spec
	storage *Storage
	index   *Index
}

func (e *EmbeDb) Add(item interface{}) error {
	if err := e.spec.CheckType(item); err != nil {
		return err
	}
	log.Print(POOL_DEGREE, POOL_SIZE, " @@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	//e.spec.test = item
	id := e.spec.GetId(item)
	log.Print(id)
	cid := Hash64a([]byte(id))
	log.Print(cid)
	return nil
}

func (e *EmbeDb) Add1(str string, item interface{}) error {
	log.Print("Теги от spec: ", e.spec.GetTags(item))
	itmX := item.(Article)
	key := Hash64a([]byte(str))
	k := e.storage.Add(key, item)
	e.index.Add(k, str)
	tgs := itmX.Tags
	e.tags.AddToTags(tgs, k)
	return nil
}

func (e *EmbeDb) Select(tagsNames []string) {
	log.Print("COUNT SELECTED:", len(e.tags.SelectByTags(tagsNames)))
	log.Print("SELECTED:", e.tags.SelectByTags(tagsNames))
	log.Print("LISTED:", e.storage.List(e.tags.SelectByTags(tagsNames)))
}

// Implements FNV-1a, non-cryptographic hash function
// created by Glenn Fowler, Landon Curt Noll and Phong Vo.
func Hash64a(data []byte) uint64 {
	var offset64 uint64 = 14695981039346656037
	var prime64 uint64 = 1099511628211
	var hash uint64 = offset64
	for _, c := range data {
		hash ^= uint64(c)
		hash *= prime64
	}
	return hash
}

type iiface struct {
	data unsafe.Pointer
}

type iface struct {
	tab  *itab
	data unsafe.Pointer
}

type itab struct {
	inter  *interfacetype
	_type  *_type
	link   *itab
	bad    int32
	unused int32
	fun    [1]uintptr // variable sized
}

type interfacetype struct {
	typ     _type
	pkgpath name
	mhdr    []imethod
}

type _type struct {
	name   string
	bits   uint
	signed bool
}

type name struct {
	bytes *byte
}

type imethod struct {
	name nameOff
	ityp typeOff
}

type nameOff int32
type typeOff int32
type textOff int32

func GetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

type Test struct {
	A1 string
	A2 string
}

type Article struct {
	Id    string
	Pub   bool
	Date  int
	Title string
	Desc  string
	Text  string
	Tags  []string
}
