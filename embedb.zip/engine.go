package embedb

// EmbeDB
// Engine
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

//import "log"

//import "time"

//import "unsafe"
//import "strconv"

// POOL_DEGREE - degree of defining the size of the pool (8 to 16)
//const POOL_DEGREE uint64 = 4

// POOL_SIZE - calculated as the number of degree, not to change!
//const POOL_SIZE uint64 = uint64(uint64(1) << POOL_DEGREE)

//const SECTION_SIZE uint64 = 6100
//const SECTION_LIMIT uint64 = 6000
const TRIAL_LIMIT int = 20000000

//
const (
	ASC = iota
	DESC
)

// New - create a new EmbeDb-struct
func New(item interface{}, id string, tags []string) (*EmbeDb, error) {
	//sId := "Id"
	//sTags := []string{"Title", "Date", "Tags"}
	spec, err := NewSpec(item, id, tags)
	if err != nil {
		return nil, err
	}
	e := &EmbeDb{
		tags:    NewTags(),
		spec:    spec,
		storage: NewStorage(),
		index:   NewIndex(),
		//sorter:  NewSorter(spec),
	}
	return e, nil
}

// EmbeDb
type EmbeDb struct {
	tags    *Tags
	spec    *Spec
	storage *Storage
	index   *Index
	//sorter  *Sorter
}

func (e *EmbeDb) Add(item interface{}) error {
	//log.Print("Теги от spec: ", e.spec.GetTags(item))
	//itmX := item.(Article)
	id := e.spec.GetId(item)
	//key := Hash64a([]byte(id))
	k := e.storage.Add(item)
	e.index.Add(id, k)
	tgs, sortIndexes := e.spec.GetTags(item) // itmX.Tags

	e.tags.AddToTags(tgs, k, sortIndexes)
	//log.Print("Заглянем внутрь тегов ", e.tags.subTags["TagsNews"].lists)
	return nil
}

/*
func (e *EmbeDb) Del(id string) error {
	num := e.index.GetNum(id)
	item := e.storage.Get(num)
	tags, _ := e.spec.GetTags(item)
	e.tags.DelFromTags(tags, num)
	e.index.Del(id)
	return nil
}

func (e *EmbeDb) Get(id string) interface{} {
	num := e.index.GetNum(id)
	item := e.storage.Get(num)
	tags, _ := e.spec.GetTags(item)
	e.tags.DelFromTags(tags, num)
	e.index.Del(id)

	if num := e.index.GetNum(id); num >= 0 {
		return e.storage.Get(num)
	}
	return nil
}
*/

func (e *EmbeDb) Select() *Query {
	return newQuery(e)
}

func (e *EmbeDb) selectDo(q *Query) []interface{} {
	//tStart := time.Now().UnixNano()
	if len(q.fields) == 0 {
		return make([]interface{}, 0)
	}
	return e.storage.List(e.limitIds(e.tags.SelectByTags(q.fields, q.sort), q.from, q.to))

}

func (e *EmbeDb) limitIds(tags []int, from int, to int) []int {
	if to > len(tags) {
		to = len(tags)
	}
	if from > len(tags) {
		from = len(tags)
	}
	//out := tags[from:to]
	return tags[from:to] //out
}

func (e *EmbeDb) limitItems(items []interface{}, from int, to int) []interface{} {
	if to > len(items) {
		to = len(items)
	}
	if from > len(items) {
		from = len(items)
	}
	//out := items[from:to]
	return items[from:to]
}

// newQuery - create a new Query-struct
func newQuery(db *EmbeDb) *Query {
	return &Query{
		db:     db,
		fields: make([]string, 0, 10),
		sort:   "",
		asc:    0,
		from:   0,
		to:     17,
	}
}

type Query struct {
	db     *EmbeDb
	fields []string
	sort   string
	asc    int
	from   int
	to     int
}

func (q *Query) ByFields(where []string) *Query {
	q.fields = where
	return q
}

func (q *Query) OrderBy(tag string, asc int) *Query {
	q.sort = tag
	q.asc = asc
	return q
}

func (q *Query) Limit(from int, to int) *Query {
	q.from = from
	q.to = to
	return q
}
func (q *Query) Do() []interface{} {
	return q.db.selectDo(q)
}
