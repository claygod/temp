package embedb

// EmbeDB
// Spec
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "reflect"
import "unsafe"

//import "log"
import "errors"
import "fmt"

//import "sort"

const (
	TYPE_INT = iota
	TYPE_INT32
	TYPE_INT64
	TYPE_UINT
	TYPE_UINT32
	TYPE_UINT64
	TYPE_FLOAT32
	TYPE_FLOAT64
)

// NewSpec - create a new Spec-struct
func NewSpec(item interface{}, cId string, cTags []string) (*Spec, error) {
	s := &Spec{
		item:            item,
		idName:          cId,
		fields:          make(map[string]field),
		offsetSortType:  make(map[string]int),
		offsetSortPtr:   make(map[string]uintptr),
		offsetTagsRoot:  make(map[string]uintptr),
		offsetTagsSlice: make(map[string]uintptr),
	}
	if err := s.parseFields(item, cTags); err != nil {
		return nil, err
	}
	//log.Print(s.fields)
	// Устанавливаем смещение для Id
	s.offsetId = s.fields[cId].Offset
	// Устанавливаем смещения длятегов
	/*
		for _, v := range s.fields {
			if v.Type == reflect.TypeOf("") && v.Name != cId {
				s.offsetTagsRoot[v.Name] = v.Offset
			} else if v.Type == reflect.TypeOf([]string{}) {
				s.offsetTagsSlice[v.Name] = v.Offset
			}
		}
	*/
	// Устанавливаем смещения
	for _, t := range cTags {
		//log.Print(" ===", t)
		if f, ok := s.fields[t]; ok {
			//if f.Type == reflect.TypeOf("") {
			//	s.offsetTagsRoot[t] = f.Offset
			//} else if f.Type == reflect.TypeOf([]string{}){
			//	s.offsetTagsSlice[t] = f.Offset
			//} else {
			//}
			//log.Print(" -----", t)
			switch f.Type {
			case reflect.TypeOf(""):
				s.offsetTagsRoot[t] = f.Offset
			case reflect.TypeOf([]string{}):
				s.offsetTagsSlice[t] = f.Offset
			case reflect.TypeOf(int(1)):
				s.offsetSortType[t] = TYPE_INT
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(int32(1)):
				s.offsetSortType[t] = TYPE_INT32
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(int64(1)):
				s.offsetSortType[t] = TYPE_INT64
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(uint(1)):
				s.offsetSortType[t] = TYPE_UINT
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(uint32(1)):
				s.offsetSortType[t] = TYPE_UINT32
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(uint64(1)):
				s.offsetSortType[t] = TYPE_UINT64
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(float32(1)):
				s.offsetSortType[t] = TYPE_FLOAT32
				s.offsetSortPtr[t] = f.Offset
			case reflect.TypeOf(float64(1)):
				s.offsetSortType[t] = TYPE_FLOAT64
				s.offsetSortPtr[t] = f.Offset
			default:
				return nil, errors.New(fmt.Sprintf(`"%s" Field can not be indexed`, t))
			}
		} else {
			return nil, errors.New(fmt.Sprintf(`Incorrect structure field name: "%s"`, t))
		}
	}
	//log.Print("Смещение Id: ", s.offsetId)
	//log.Print("Смещение TagsRoot: ", s.offsetTagsRoot)
	//log.Print("Смещение TagsSlice: ", s.offsetTagsSlice)
	return s, nil
}

// Spec - спецификация
type Spec struct {
	item            interface{}
	itemName        string
	itemType        reflect.Type
	idName          string
	offsetId        uintptr
	offsetSortType  map[string]int
	offsetSortPtr   map[string]uintptr
	offsetTagsRoot  map[string]uintptr
	offsetTagsSlice map[string]uintptr
	fields          map[string]field
	test            interface{}
}

func (s *Spec) GetId(item interface{}) string {
	return *(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + s.offsetId))
}

func (s *Spec) GetSortParam(tag string) (int, uintptr, bool) {
	if tp, ok := s.offsetSortType[tag]; ok {
		return tp, s.offsetSortPtr[tag], true
	}
	return 0, 0, false
}

func (s *Spec) GetTags(item interface{}) []string {
	out := make([]string, 0, 100)
	// Root tags
	for k, t := range s.offsetTagsRoot {
		out = append(out, k+*(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + t)))
	}
	// Slice tags
	for k, t := range s.offsetTagsSlice {
		slc := *(*[]string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + t))
		for _, t2 := range slc {
			out = append(out, k+t2)
		}
	}
	// параметры для индексации под сортировку
	//sortIndexes := make(map[string]int)
	//for k, t := range s.offsetSortPtr {
	//	sortIndexes[k] = *(*int)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + t))
	//}
	return out //, sortIndexes
}

func (s *Spec) GetSortIndexes(item interface{}) map[string]int {
	// параметры для индексации под сортировку
	sortIndexes := make(map[string]int)
	for k, t := range s.offsetSortPtr {
		sortIndexes[k] = *(*int)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + t))
	}
	return sortIndexes
}

func (s *Spec) SetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

func (s *Spec) parseFields(item interface{}, fields []string) error {
	t1 := reflect.TypeOf(item)
	v1 := reflect.ValueOf(item)
	v1 = reflect.Indirect(v1)
	//s.itemName = t1.Name()
	s.itemType = v1.Type()
	//log.Print(t1.Name())
	for _, key := range fields {
		if t2, ok := t1.FieldByName(key); ok {
			s.fields[t2.Name] = field{
				Name:   t2.Name,
				Type:   t2.Type,
				Offset: t2.Offset,
			}
		} else {
			return errors.New("This field in the structure is not")
		}

	}
	s.offsetId = s.fields["Id"].Offset
	//log.Print(s.fields)
	return nil
}

// field structure
type field struct {
	Name   string
	Type   reflect.Type
	Offset uintptr
}

type iiface struct {
	data unsafe.Pointer
}

type iface struct {
	tab  *itab
	data unsafe.Pointer
}

type itab struct {
	inter  *interfacetype
	_type  *_type
	link   *itab
	bad    int32
	unused int32
	fun    [1]uintptr // variable sized
}

type interfacetype struct {
	typ     _type
	pkgpath name
	mhdr    []imethod
}

type _type struct {
	name   string
	bits   uint
	signed bool
}

type name struct {
	bytes *byte
}

type imethod struct {
	name nameOff
	ityp typeOff
}

type nameOff int32
type typeOff int32
type textOff int32

func GetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

type Test struct {
	A1 string
	A2 string
}
