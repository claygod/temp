package embedb

// EmbeDB
// Spec
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "reflect"
import "unsafe"

import "log"
import "errors"
import "fmt"

// NewSpec - create a new Spec-struct
func NewSpec(item interface{}, cId string, cTags []string) (*Spec, error) {
	s := &Spec{
		item:            item,
		fields:          make(map[string]field),
		offsetTagsRoot:  make(map[string]uintptr),
		offsetTagsSlice: make(map[string]uintptr),
	}
	if err := s.parseFields(item, []string{"Id", "Pub", "Date", "Title", "Tags"}); err != nil {
		return nil, err
	}
	//log.Print(s.fields)
	// Устанавливаем смещение для Id
	s.offsetId = s.fields[cId].Offset
	// Устанавливаем смещения длятегов
	for _, v := range s.fields {
		if v.Type == reflect.TypeOf("") && v.Name != cId {
			s.offsetTagsRoot[v.Name] = v.Offset
		} else if v.Type == reflect.TypeOf([]string{}) {
			s.offsetTagsSlice[v.Name] = v.Offset
		}
	}
	log.Print("Смещение Id: ", s.offsetId)
	log.Print("Смещение TagsRoot: ", s.offsetTagsRoot)
	log.Print("Смещение TagsSlice: ", s.offsetTagsSlice)
	return s, nil
}

// Spec - спецификация
type Spec struct {
	item            interface{}
	itemName        string
	itemType        reflect.Type
	offsetId        uintptr
	offsetTagsRoot  map[string]uintptr
	offsetTagsSlice map[string]uintptr
	fields          map[string]field
	test            interface{}
}

func (s *Spec) GetId(item interface{}) string {
	// z := (*iface)(unsafe.Pointer(&item))
	// log.Print("-------SPEC---------")
	// log.Print(*(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + s.itemOffsetId)))
	return *(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + s.offsetId))
}

func (s *Spec) GetTags(item interface{}) []string {
	out := make([]string, 0, 100)
	// Root tags
	for k, t := range s.offsetTagsRoot {
		out = append(out, k+*(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + t)))
	}
	// Slice tags
	for k, t := range s.offsetTagsSlice {
		slc := *(*[]string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + t))
		for _, t2 := range slc {
			out = append(out, k+t2)
		}
	}
	return out
}

func (s *Spec) SetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

func (s *Spec) CheckType(item interface{}) error {
	if t := reflect.TypeOf(item); t != s.itemType {
		msg := fmt.Sprintf("Not the same types (%s and %s)",
			s.itemName,
			t.Name())
		return errors.New(msg)
	}
	return nil
}

func (s *Spec) parseFields(item interface{}, fields []string) error {
	t1 := reflect.TypeOf(item)
	v1 := reflect.ValueOf(item)
	v1 = reflect.Indirect(v1)
	//s.itemName = t1.Name()
	s.itemType = v1.Type()
	//log.Print(t1.Name())
	for _, key := range fields {
		if t2, ok := t1.FieldByName(key); ok {
			s.fields[t2.Name] = field{
				Name:   t2.Name,
				Type:   t2.Type,
				Offset: t2.Offset,
			}
		} else {
			return errors.New("This field in the structure is not")
		}

	}
	s.offsetId = s.fields["Id"].Offset
	//log.Print(s.fields["Id"].Offset)
	return nil
}

// field structure
type field struct {
	Name   string
	Type   reflect.Type
	Offset uintptr
}
