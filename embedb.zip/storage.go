package embedb

// EmbeDB
// Storage
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"

//import "sync/atomic"
//import "runtime"

//import "log"

//import "time"

// NewStorage - create a new SubStore-struct
func NewStorage() *Storage {
	s := &Storage{arr: make([]interface{}, 0, 100)}
	return s
}

// SubStore - хранилище субструктур (секций)
type Storage struct {
	sync.Mutex
	arr []interface{}
}

func (s *Storage) Add(item interface{}) int {
	s.Lock()
	num := len(s.arr)
	s.arr = append(s.arr, item)
	s.Unlock()
	return num
}

func (s *Storage) AddUnsafe(item interface{}) int {
	//s.Lock()
	num := len(s.arr)
	s.arr = append(s.arr, item)
	//s.Unlock()
	return num
}

func (s *Storage) Update(item interface{}, num int) bool {
	//log.Print("- вошли в режим 'update' в хранилище")
	s.Lock()
	if len(s.arr) <= num {
		s.Unlock()
		//log.Print("- update не получилось для: ", num)
		return false
	}
	s.arr[num] = item
	//log.Print("- update получилось для: ", num)
	s.Unlock()
	return true
}

//func (s *SubStore) Del(id uint64) error {
//	return nil
//}

func (s *Storage) Get(id int) interface{} {
	s.Lock()
	if len(s.arr) < id {
		s.Unlock()
		return nil
	}
	s.Unlock()
	return s.arr[id]
}

func (s *Storage) List(m []int, asc int) []interface{} {
	out := make([]interface{}, len(m))
	s.Lock()
	if asc == ASC {
		for i, u := (len(m) - 1), 0; i >= 0; i, u = i-1, u+1 {
			out[u] = s.arr[m[i]]
		}

	} else {
		for i, id := range m {
			out[i] = s.arr[id]
		}
	}
	s.Unlock()
	return out
}
