package embedb

// EmbeDB
// Storage
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sync/atomic"
import "runtime"

// import "log"

// NewStorage - create a new Storage-struct
func NewStorage() *Storage {
	s := &Storage{subStores: make([]SubStore, POOL_SIZE)}
	for i := uint64(0); i < POOL_SIZE; i++ {
		s.subStores[i] = NewSubStore()
	}
	return s
}

// Storage - хранилище структур
type Storage struct {
	//sync.Mutex
	subStores []SubStore
}

func (s *Storage) Add(id uint64, item interface{}) uint64 {
	numSubStore := (POOL_SIZE - 1) & id
	//log.Print("Присвоен Номер субсекции: ", (POOL_SIZE-1)&id)
	return s.subStores[(POOL_SIZE-1)&id].Add(item) + (numSubStore << 32)
}

func (s *Storage) List(m map[uint64]bool) []interface{} {
	var ch chan []interface{}
	var totalCount int
	out2 := make([]interface{}, 0, 100)
	for k, v := range s.SortIdBySubStore(m) {
		out2 = append(out2, s.subStores[k].Get(v, ch)...)
		totalCount += len(v)
	}
	//log.Print("Storage_List получил m: ", m, " len(m):", len(m))
	return out2
	out := make([]interface{}, 0, totalCount)
	for i := 0; i < len(m); i++ {
		x := <-ch
		out = append(out, x...)
	}
	return out
}

func (s *Storage) SortIdBySubStore(m map[uint64]bool) map[uint64][]uint64 { // сортировка
	out := make(map[uint64][]uint64)
	for k, _ := range m {
		sect := k >> 32
		if _, ok := out[sect]; !ok {
			out[sect] = make([]uint64, 0, 1)
		}
		out[sect] = append(out[sect], uint64(uint32(k)))
	}
	//log.Print("До сортировки:", m)
	//log.Print("После сортировки:", out)
	return out
}

// NewSubStore - create a new SubStore-struct
func NewSubStore() SubStore {
	s := SubStore{arr: make([]interface{}, 0, 100)}
	return s
}

// SubStore - хранилище субструктур (секций)
type SubStore struct {
	sync.Mutex
	hasp    uint32
	updated uint64
	arr     []interface{}
}

func (s *SubStore) Add(item interface{}) uint64 {
	s.Lock()
	num := len(s.arr)
	s.arr = append(s.arr, item)
	s.Unlock()
	// log.Print("Присвоен ID в субсекции: ", uint64(num))
	return uint64(num)
}

func (s *SubStore) Del(id uint64) error {
	return nil
}
func (s *SubStore) Get(ids []uint64, ch chan []interface{}) []interface{} {
	out := make([]interface{}, 0, len(ids))
	s.Lock()
	for _, id := range ids {
		out = append(out, s.arr[id])
	}
	s.Unlock()
	//log.Print("SubStore-Get ids: ", ids)
	//log.Print("SubStore-Get out: ", out)
	return out
	//ch <- out
}

func (m *SubStore) lock(lock *uint32) bool {
	for i := TRIAL_LIMIT; i > 0; i-- {
		if *lock == 0 && atomic.CompareAndSwapUint32(lock, 0, 1) {
			break
		}
		if i == 5 {
			return false
		}
		runtime.Gosched()
	}
	return true
}

func (m *SubStore) unlock(lock *uint32) bool {
	for i := TRIAL_LIMIT; i > 0; i-- {
		if *lock == 0 && atomic.CompareAndSwapUint32(lock, 1, 0) {
			break
		}
		if i == 5 {
			return false
		}
		runtime.Gosched()
	}
	return true
}
