package embedb

// EmbeDB
// Storage
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sync/atomic"
import "runtime"

//import "log"

// NewStorage - create a new Storage-struct
func NewStorage() *Storage {
	s := &Storage{subStores: make([]SubStore, POOL_SIZE)}
	for i := uint64(0); i < POOL_SIZE; i++ {
		s.subStores[i] = NewSubStore()
	}
	return s
}

// Storage - хранилище структур
type Storage struct {
	//sync.Mutex
	subStores []SubStore
}

func (s *Storage) Add(id uint64, item interface{}) uint64 {
	numSubStore := (POOL_SIZE - 1) & id
	//log.Print(id, "=======", (POOL_SIZE-1)&id, POOL_SIZE)
	// s.subStores[numSubStore].Add(item)
	return s.subStores[(POOL_SIZE-1)&id].Add(item) + (numSubStore << 32)
}

// NewSubStore - create a new SubStore-struct
func NewSubStore() SubStore {
	s := SubStore{arr: make([]interface{}, 100)}
	return s
}

// SubStore - хранилище субструктур (секций)
type SubStore struct {
	sync.Mutex
	hasp    uint32
	updated uint64
	arr     []interface{}
}

func (s *SubStore) Add(item interface{}) uint64 {
	s.Lock()
	//s.lock(&s.hasp)
	num := len(s.arr)
	s.arr = append(s.arr, item)
	//s.hasp = 0
	//s.unlock(&s.hasp)
	s.Unlock()
	return uint64(num)
}

func (s *SubStore) Del(id uint64) error {
	return nil
}
func (s *SubStore) Get(id uint64) error {
	return nil
}

func (m *SubStore) lock(lock *uint32) bool {
	for i := TRIAL_LIMIT; i > 0; i-- {
		if *lock == 0 && atomic.CompareAndSwapUint32(lock, 0, 1) {
			break
		}
		if i == 5 {
			return false
		}
		runtime.Gosched()
	}
	return true
}

func (m *SubStore) unlock(lock *uint32) bool {
	for i := TRIAL_LIMIT; i > 0; i-- {
		if *lock == 0 && atomic.CompareAndSwapUint32(lock, 1, 0) {
			break
		}
		if i == 5 {
			return false
		}
		runtime.Gosched()
	}
	return true
}
