package embedb

// EmbeDB
// Storage
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"

//import "sync/atomic"
//import "runtime"

//import "log"
//import "time"

// NewSubStore - create a new SubStore-struct
func NewSubStore() SubStore {
	s := SubStore{arr: make([]interface{}, 0, 100)}
	return s
}

// NewSubStore2 - create a new SubStore-struct
func NewSubStore2() *SubStore {
	s := &SubStore{arr: make([]interface{}, 0, 100)}
	return s
}

// SubStore - хранилище субструктур (секций)
type SubStore struct {
	sync.Mutex
	// hasp uint32
	//updated uint64
	arr []interface{}
}

func (s *SubStore) Add(item interface{}) int {
	s.Lock()
	num := len(s.arr)
	s.arr = append(s.arr, item)
	s.Unlock()
	// log.Print("Присвоен ID в субсекции: ", uint64(num))
	return num
}

func (s *SubStore) Del(id uint64) error {
	return nil
}
func (s *SubStore) Get222(ids []uint64, ch chan []interface{}) []interface{} {
	out := make([]interface{}, 0, len(ids))
	s.Lock()
	for _, id := range ids {
		out = append(out, s.arr[id])
	}
	s.Unlock()
	//log.Print("SubStore-Get ids: ", ids)
	//log.Print("SubStore-Get out: ", out)
	return out
	//ch <- out
}

func (s *SubStore) List(m []int) []interface{} { // map[uint64]bool
	out := make([]interface{}, 0, len(m))
	s.Lock()
	for _, id := range m {
		out = append(out, s.arr[id])
	}
	s.Unlock()
	return out
}
