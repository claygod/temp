package embedb

// EmbeDB
// Engine
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "log"

//import "unsafe"

const POOL_SIZE int = 65534

//const SECTION_SIZE uint64 = 6100
//const SECTION_LIMIT uint64 = 6000
//const TRIAL_LIMIT int = 20000000

// New - create a new EmbeDb-struct
func New(item interface{}) (*EmbeDb, error) {
	spec, err := NewSpec(item)
	if err != nil {
		return nil, err
	}
	e := &EmbeDb{
		id:   NewIdPool(),
		sect: NewSectPool(),
		tags: NewTags(),
		spec: spec,
	}
	return e, nil
}

// EmbeDb
type EmbeDb struct {
	id   *IdPool
	sect *SectPool
	tags *Tags
	spec *Spec
}

func (e *EmbeDb) Add(item interface{}) error {
	if err := e.spec.CheckType(item); err != nil {
		return err
	}
	//e.spec.test = item
	id := e.spec.GetId(item)
	log.Print(id)
	cid := Hash64a([]byte(id))
	log.Print(cid)
	return nil
}

// NewIdPool - create a new IdPool-struct
func NewIdPool() *IdPool {
	p := &IdPool{}
	for i := 0; i < POOL_SIZE; i++ {
		p.items[i] = NewId()
	}
	return p
}

// IdPool - хранилище id(строка)/id(current)
type IdPool struct {
	sync.Mutex
	items [POOL_SIZE]Id
}

// NewId - create a new Id-struct
func NewId() Id {
	i := Id{arr: make(map[string]uint64)}
	return i
}

// Id - map[id(строка)]id(current)
type Id struct {
	sync.Mutex
	arr map[string]uint64
}

// NewSectPool - create a new SectPool-struct
func NewSectPool() *SectPool {
	s := &SectPool{}
	for i := 0; i < POOL_SIZE; i++ {
		s.items[i] = NewSection()
	}
	return s
}

// SectionsPool - хранилище id(current)/структура
type SectPool struct {
	sync.Mutex
	items [POOL_SIZE]Section
}

// NewSection - create a new Section-struct
func NewSection() Section {
	s := Section{arr: make(map[uint64]interface{})}
	return s
}

// map[id(current)]структура
type Section struct {
	sync.Mutex
	arr map[uint64]interface{}
}

// NewTags - create a new Tags-struct
func NewTags() *Tags {
	i := &Tags{arr: make(map[uint64]uint64)}
	return i
}

// В индексе map[имя_тега]id(current)
type Tags struct {
	sync.Mutex
	arr map[uint64]uint64
}

// Implements FNV-1a, non-cryptographic hash function
// created by Glenn Fowler, Landon Curt Noll and Phong Vo.
func Hash64a(data []byte) uint64 {
	var offset64 uint64 = 14695981039346656037
	var prime64 uint64 = 1099511628211
	var hash uint64 = offset64
	for _, c := range data {
		hash ^= uint64(c)
		hash *= prime64
	}
	return hash
}
