package embedb

// EmbeDB
// Tests and benchmarks
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

//import "fmt"
import "testing"

// import "strconv"
import "encoding/gob"
import "bytes"
import "log"

import "reflect"
import "unsafe"

func Test201(t *testing.T) {
	p := GetTestStruct()
	//t1 := reflect.TypeOf(p)
	//log.Print(t1)
	z := (*iface)(unsafe.Pointer(&p))
	log.Print("----------------")
	//log.Print(z.data)
	log.Print(*(*string)(unsafe.Pointer(uintptr(unsafe.Pointer(z.data)) + 16)))
	//log.Print(z.tab)
}

func Test200(t *testing.T) {
	//a := Article{Id: "a1", Title: "abc"}
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}

	edb, err := New(a)
	if err != nil {
		t.Error("Failed to create a new database:", err)
	}
	edb.Add(a)
}

/*
func Test100(t *testing.T) {
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	//dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		t.Error("encode error:", err)
	}
}

func Test101(t *testing.T) {
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	b := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "Two article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	fmt.Print(unsafe.Offsetof(a.Desc), "\r\n")
	fmt.Print(unsafe.Offsetof(b.Desc), "\r\n")

}
*/

func BenchmarkFieldUnsafe(b *testing.B) {
	b.StopTimer()
	p := GetTestStruct()
	//z := (*iface)(unsafe.Pointer(&p))
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		//z := (*iface)(unsafe.Pointer(&p))
		_ = *(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&p)).data)) + 16))
	}
}

func BenchmarkFieldReflect(b *testing.B) {
	b.StopTimer()
	p := GetTestStruct()

	//z := (*iface)(unsafe.Pointer(&p))
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		t1 := reflect.TypeOf(p)
		t1.Field(1)
	}
}

func BenchmarkGobEn(b *testing.B) {
	b.StopTimer()
	//arr = make([]Article, 0)
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	//for i := 0; i < 10000; i++ {
	//	arr = append(arr, a)
	//}

	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	//dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		log.Fatal("encode error:", err)
	}
	//var q Article
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		//	a.Id = strconv.Itoa(n)
		//	d.Add(a, fu)
		enc.Encode(a)
		//dec.Decode(&q)
	}
}
func BenchmarkGobEnDe(b *testing.B) {
	b.StopTimer()
	//arr = make([]Article, 0)
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	//for i := 0; i < 10000; i++ {
	//	arr = append(arr, a)
	//}

	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		log.Fatal("encode error:", err)
	}
	var q Article
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		//	a.Id = strconv.Itoa(n)
		//	d.Add(a, fu)
		enc.Encode(a)
		dec.Decode(&q)
	}
}

func BenchmarkGobEnParallel(b *testing.B) {
	b.StopTimer()
	//arr = make([]Article, 0)
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}

	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	//dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		log.Fatal("encode error:", err)
	}
	//for i := 0; i < 10000; i++ {
	//	enc.Encode(a)
	//}

	//var q Article
	b.StartTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			enc.Encode(a)
			//dec.Decode(&q)
		}
	})
}

type Article struct {
	Id    string
	Pub   bool
	Date  int
	Title string
	Desc  string
	Text  string
	Tags  []string
}

func GetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

type Test struct {
	A1 string
	A2 string
}

type iiface struct {
	data unsafe.Pointer
}

type iface struct {
	tab  *itab
	data unsafe.Pointer
}

type itab struct {
	inter  *interfacetype
	_type  *_type
	link   *itab
	bad    int32
	unused int32
	fun    [1]uintptr // variable sized
}

type interfacetype struct {
	typ     _type
	pkgpath name
	mhdr    []imethod
}

type _type struct {
	name   string
	bits   uint
	signed bool
}

type name struct {
	bytes *byte
}

type imethod struct {
	name nameOff
	ityp typeOff
}

type nameOff int32
type typeOff int32
type textOff int32
