package embedb

// EmbeDB
// Spec
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "reflect"
import "unsafe"
import "log"
import "errors"
import "fmt"

// NewSpec - create a new Spec-struct
func NewSpec(item interface{}) (*Spec, error) {
	s := &Spec{
		item:   item,
		fields: make(map[string]field),
	}
	if err := s.parseFields(item, []string{"Id", "Pub", "Date", "Tags"}); err != nil {
		return nil, err
	}
	log.Print(s.fields)
	return s, nil
}

// Spec - спецификация
type Spec struct {
	item         interface{}
	itemName     string
	itemType     reflect.Type
	itemOffsetId uintptr
	fields       map[string]field
	test         interface{}
}

func (s *Spec) GetId(item interface{}) string {
	// z := (*iface)(unsafe.Pointer(&item))
	// log.Print("-------SPEC---------")
	// log.Print(*(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + s.itemOffsetId)))
	return *(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&item)).data)) + s.itemOffsetId))
}

func (s *Spec) SetTestStruct() interface{} {
	t := Test{A1: "aaaa00", A2: "bbbertyrt"}
	//t1 := t.(interface{})
	return t
}

func (s *Spec) CheckType(item interface{}) error {
	if t := reflect.TypeOf(item); t != s.itemType {
		msg := fmt.Sprintf("Not the same types (%s and %s)",
			s.itemName,
			t.Name())
		return errors.New(msg)
	}
	return nil
}

func (s *Spec) parseFields(item interface{}, fields []string) error {
	t1 := reflect.TypeOf(item)
	v1 := reflect.ValueOf(item)
	v1 = reflect.Indirect(v1)
	//s.itemName = t1.Name()
	s.itemType = v1.Type()
	log.Print(t1.Name())
	for _, key := range fields {
		if t2, ok := t1.FieldByName(key); ok {
			s.fields[t2.Name] = field{
				Name:   t2.Name,
				Type:   t2.Type,
				Offset: t2.Offset,
			}
		} else {
			return errors.New("This field in the structure is not")
		}

	}
	s.itemOffsetId = s.fields["Id"].Offset
	log.Print(s.fields["Id"].Offset)
	return nil
}

// field structure
type field struct {
	Name   string
	Type   reflect.Type
	Offset uintptr
}
