package embedb

// EmbeDB
// Index
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"

// NewIndex - create a new Index-struct
func NewIndex() *Index {
	s := &Index{subIndexes: make([]SubIndex, POOL_SIZE)}
	for i := uint64(0); i < POOL_SIZE; i++ {
		s.subIndexes[i] = NewSubIndex()
	}
	return s
}

// Index - хранилище индексов структур
type Index struct {
	//sync.Mutex
	subIndexes []SubIndex
}

func (i *Index) Add(idInt uint64, idStr string) {
	i.subIndexes[(POOL_SIZE-1)&idInt].Add(idInt, idStr)
}

// NewSubIndex - create a new SubIndex-struct
func NewSubIndex() SubIndex {
	s := SubIndex{arr: make(map[uint64]map[string]uint64)}
	return s
}

// SubIndex - хранилище субиндексов (секций)
type SubIndex struct {
	sync.Mutex
	arr map[uint64]map[string]uint64
}

func (s *SubIndex) Add(idInt uint64, idStr string) {
	s.Lock()
	if _, ok := s.arr[idInt]; !ok {
		s.arr[idInt] = make(map[string]uint64)
	}
	s.arr[idInt][idStr] = idInt
	s.Unlock()
}
