package embedb

// EmbeDB
// Index
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"
import "sort"

// NewIndex - create a new Index-struct
func NewIndex() *Index {
	ix := &Index{arr: make(map[string]int)}
	return ix
}

type Index struct {
	sync.Mutex
	arr map[string]int
}

func (ix *Index) Add(id string, num int) bool {
	ix.Lock()
	if _, ok := ix.arr[id]; ok {
		ix.Unlock()
		return false
	}
	ix.arr[id] = num
	ix.Unlock()
	return true
}

func (ix *Index) AddUnsafe(id string, num int) bool {
	//ix.Lock()
	if _, ok := ix.arr[id]; ok {
		ix.Unlock()
		return false
	}
	ix.arr[id] = num
	//ix.Unlock()
	return true
}

func (ix *Index) Del(id string) bool {
	ix.Lock()
	if _, ok := ix.arr[id]; !ok {
		ix.Unlock()
		return false
	}
	delete(ix.arr, id)
	ix.Unlock()
	return true
}

func (ix *Index) GetNum(id string) int {
	ix.Lock()
	if _, ok := ix.arr[id]; !ok {
		ix.Unlock()
		return -1
	}
	ix.Unlock()
	return ix.arr[id]
}

func (ix *Index) GetAll() []int {
	ix.Lock()
	all := make([]int, len(ix.arr))
	i := 0
	for _, k := range ix.arr {
		all[i] = k
		i++
	}
	ix.Unlock()
	sort.Sort(sort.IntSlice(all))
	return nil
}
