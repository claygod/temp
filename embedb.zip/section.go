package embedb

// EmbeDB
// Sections
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"

// NewSectPool - create a new SectPool-struct
func NewSectPool() *SectPool {
	s := &SectPool{}
	for i := uint64(0); i < POOL_SIZE; i++ {
		s.items[i] = NewSection()
	}
	return s
}

// SectionsPool - хранилище id(current)/структура
type SectPool struct {
	sync.Mutex
	items [POOL_SIZE]Section
}

// NewSection - create a new Section-struct
func NewSection() Section {
	s := Section{arr: make(map[uint64]interface{})}
	return s
}

// map[id(current)]структура
type Section struct {
	sync.Mutex
	updated uint64
	arr     map[uint64]interface{}
}

func (s *Section) Add(item interface{}) error {
	return nil
}

func (s *Section) Del(id string) error {
	return nil
}
func (s *Section) Get(id string) error {
	return nil
}
