package embedb

// EmbeDB
// Id
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "sync"

// NewIdPool - create a new IdPool-struct
func NewIdPool() *IdPool {
	p := &IdPool{}
	for i := uint64(0); i < POOL_SIZE; i++ {
		p.items[i] = NewId()
	}
	return p
}

// IdPool - хранилище id(строка)/id(current)
type IdPool struct {
	sync.Mutex
	items [POOL_SIZE]Id
}

// NewId - create a new Id-struct
func NewId() Id {
	i := Id{arr: make(map[string]uint64)}
	return i
}

// Id - map[id(строка)]id(current)
type Id struct {
	sync.Mutex
	arr map[string]uint64
}
