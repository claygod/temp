package embedb

// EmbeDB
// Tests and benchmarks
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

//import "fmt"
import "testing"

import "strconv"
import "encoding/gob"
import "bytes"
import "log"

import "reflect"
import "unsafe"

func TestStorage(t *testing.T) {
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}

	s := NewStorage()
	s.Add(256, a)
}

func TestEngine(t *testing.T) {
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}

	s, _ := New(a)
	//s.Add(256, a)
	for n := 0; n < 501; n++ {
		s.Add1(strconv.Itoa(n)+"xxx"+strconv.Itoa(n)+"xxx"+strconv.Itoa(n)+"xxx"+strconv.Itoa(n), a)
	}
	s.Select([]string{"100", "101"})
	log.Print("Получилось: ", s.tags.subTags)
	for k, v := range s.tags.subTags {
		log.Print(" -- ", k, ":", v.count)
	}
}

func Test201(t *testing.T) {
	p := GetTestStruct()
	//t1 := reflect.TypeOf(p)
	//log.Print(t1)
	z := (*iface)(unsafe.Pointer(&p))
	log.Print("----------------")
	//log.Print(z.data)
	log.Print(*(*string)(unsafe.Pointer(uintptr(unsafe.Pointer(z.data)) + 16)))
	//log.Print(z.tab)
}

func Test200(t *testing.T) {
	//a := Article{Id: "a1", Title: "abc"}
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}

	edb, err := New(a)
	if err != nil {
		t.Error("Failed to create a new database:", err)
	}
	edb.Add(a)
}

/*
func Test100(t *testing.T) {
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	//dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		t.Error("encode error:", err)
	}
}

func Test101(t *testing.T) {
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	b := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "Two article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	fmt.Print(unsafe.Offsetof(a.Desc), "\r\n")
	fmt.Print(unsafe.Offsetof(b.Desc), "\r\n")

}
*/

func BenchmarkEngineAdd(b *testing.B) {
	b.StopTimer()
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	s, _ := New(a)

	b.StartTimer()
	for n := 0; n < b.N; n++ {
		s.Add1(strconv.Itoa(n), a)
	}
}

func BenchmarkEngineAddParallel(b *testing.B) {
	b.StopTimer()
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	s, _ := New(a)
	n := 0
	b.StartTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			s.Add1(strconv.Itoa(n), a)
			n++
		}
	})
}

func BenchmarkStorageAdd(b *testing.B) {
	b.StopTimer()
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	s := NewStorage()

	b.StartTimer()
	for n := 0; n < b.N; n++ {
		s.Add(uint64(n), a)
	}
}

func BenchmarkStorageAddParallel(b *testing.B) {
	b.StopTimer()
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	s := NewStorage()
	n := uint64(0)
	b.StartTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			s.Add(uint64(n), a)
			n++
		}
	})
}

func BenchmarkFieldUnsafe(b *testing.B) {
	b.StopTimer()
	p := GetTestStruct()
	//z := (*iface)(unsafe.Pointer(&p))
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		//z := (*iface)(unsafe.Pointer(&p))
		_ = *(*string)(unsafe.Pointer(uintptr(unsafe.Pointer((*iface)(unsafe.Pointer(&p)).data)) + 16))
	}
}

func BenchmarkFieldReflect(b *testing.B) {
	b.StopTimer()
	p := GetTestStruct()

	//z := (*iface)(unsafe.Pointer(&p))
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		t1 := reflect.TypeOf(p)
		t1.Field(1)
	}
}

func BenchmarkGobEn(b *testing.B) {
	b.StopTimer()
	//arr = make([]Article, 0)
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	//for i := 0; i < 10000; i++ {
	//	arr = append(arr, a)
	//}

	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	//dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		log.Fatal("encode error:", err)
	}
	//var q Article
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		//	a.Id = strconv.Itoa(n)
		//	d.Add(a, fu)
		enc.Encode(a)
		//dec.Decode(&q)
	}
}
func BenchmarkGobEnDe(b *testing.B) {
	b.StopTimer()
	//arr = make([]Article, 0)
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}
	//for i := 0; i < 10000; i++ {
	//	arr = append(arr, a)
	//}

	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		log.Fatal("encode error:", err)
	}
	var q Article
	b.StartTimer()
	for n := 0; n < b.N; n++ {
		//	a.Id = strconv.Itoa(n)
		//	d.Add(a, fu)
		enc.Encode(a)
		dec.Decode(&q)
	}
}

func BenchmarkGobEnParallel(b *testing.B) {
	b.StopTimer()
	//arr = make([]Article, 0)
	a := Article{
		Id:    "a1",
		Pub:   true,
		Date:  234234234231,
		Title: "First article",
		Desc:  "Description",
		Text:  "Big text body",
		Tags:  []string{"news", "april"},
	}

	var network bytes.Buffer        // Stand-in for a network connection
	enc := gob.NewEncoder(&network) // Will write to network.
	//dec := gob.NewDecoder(&network) // Will read from network.

	err := enc.Encode(a)
	if err != nil {
		log.Fatal("encode error:", err)
	}
	//for i := 0; i < 10000; i++ {
	//	enc.Encode(a)
	//}

	//var q Article
	b.StartTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			enc.Encode(a)
			//dec.Decode(&q)
		}
	})
}

type Article struct {
	Id    string
	Pub   bool
	Date  int
	Title string
	Desc  string
	Text  string
	Tags  []string
}
