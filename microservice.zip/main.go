package main

// Microservice
// Main
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import (
	"fmt"
	//"net/http"
	//"net/http/httptest"

	"github.com/claygod/Bxog"
	//"github.com/claygod/microservice/tools"
)

// Main
func main() {
	fmt.Print("START\n")

	conf, err := NewTuner("config.toml")
	if err != nil {
		panic(err) // "Error in the application configuration"
	}
	//store := NewStorage(conf)

	hr := NewHandler(conf)
	h := hr.Handle(hr.Test).
		Before(hr.Store.Metric.Start).
		After(hr.Store.Metric.End)

	m := bxog.New()
	m.Add("/:id", h.Run)
	m.Start(conf.Main.Port)

	//fmt.Print("END\n")
}
