#include <stdio.h>

void testLibFunc () {
    // bla-bla
    printf("testLibFunc");
    //int i;
}

void testLibFunc2 () {
    int i = 5;
    printf("testLibFunc2 %d", i);

}

void effe22 () {
    int i = 5;
    printf("effe2 %d", i);

}

int adds2(int x1, int x2)
 {
     return x1 + x2;
 }
