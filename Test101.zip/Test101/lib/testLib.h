// Headers
int adds2(int, int);
void testLibFunc ();

void testLibFunc2 ();
void effe22 ();
