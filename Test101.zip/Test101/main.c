#include <stdio.h>
#include <stdlib.h>
#include "lib/testLib.h"

int main() {
    printf("Hello world!\n");
    printf("dfgd\n");
    testLibFunc ();

    adds2(2,6);
    return 0;
    /* fsdf */
}
