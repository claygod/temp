var MyApp = {
	mainFrame: document.getElementById('main_frame'),
	frameToTop: function(frame, num){
		var curr = document.getElementById(frame);
		//document.getElementById('okno2').innerHTML = curr.id;
		var papa = curr.parentNode;
		var first = papa.children[num];
		if (first !== curr) {
			papa.insertBefore(curr, first);
		}
	}
};

function parseUrl(){
    alert (location.hash);
}
// parseUrl();
function clearPanel(){
    // You can put some code in here to do fancy DOM transitions, such as fade-out or slide-in.
}

Path.map("#/home").to(function(){
	var okno = document.getElementById('okno');
	//okno.innerHTML =  "Users!";
	MyApp.frameToTop('s10', 1);
	MyApp.frameToTop('home', 1);
	//MyApp.frameToTop('slide', 1);
    //alert("Users!");
	// var newParent = this.parentNode.id == 'cont1' ? 'cont2' : 'cont1';
	// insertBefore

});

Path.map("#/s1").to(function(){
	var okno = document.getElementById('okno');
	//okno.innerHTML =  "Comments!";
	//MyApp.frameToTop('s1', 1);
	MyApp.frameToTop('s1', 1);
    //alert("Comments!");
	/*
	var curr = document.getElementById('comments');
	var papa = document.getElementById('comments').parentNode;
	var first = papa.children[0];
	//okno.innerHTML =  MyApp.mainFrame;
	if (first !== curr) {
		papa.insertBefore(curr, papa.children[0]);
	}
	*/
	
}).enter(clearPanel);

Path.map("#/s2").to(function(){
	var okno = document.getElementById('okno');
	//okno.innerHTML =  "Posts!";
	//MyApp.frameToTop('string', 0);
	MyApp.frameToTop('s2', 1);
    //alert("Posts!");
}).enter(clearPanel);


Path.map("#/s3").to(function(){
	var okno = document.getElementById('okno');
	//okno.innerHTML =  "Home!";
	MyApp.frameToTop('s3', 1);
   // alert("home");
});

Path.map("#/s4").to(function(){
	var okno = document.getElementById('okno');
	//okno.innerHTML =  "Home!";
	MyApp.frameToTop('s4', 1);
   // alert("home");
});

Path.map("#/s5").to(function(){
	var okno = document.getElementById('okno');
	//okno.innerHTML =  "Home!";
	MyApp.frameToTop('s5', 1);
	MyApp.frameToTop('s50', 1);
   // alert("home");
});

Path.root("#/home");

Path.listen();