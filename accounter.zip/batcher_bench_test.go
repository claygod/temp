package accounter

// Accounter
// Batcher bench
// Copyright © 2017 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import (
	"sync"
	"testing"
)

func BenchmarkBatchSyncMapStore(b *testing.B) {
	b.StopTimer()
	var inbox sync.Map
	tr := &Transaction{}
	b.StartTimer()
	for i := 0; i < b.N; i++ {
		inbox.Store(i, tr)
	}
}
func BenchmarkBatchMapStore(b *testing.B) {
	b.StopTimer()
	inbox := make(map[int]interface{})
	tr := &Transaction{}
	b.StartTimer()
	for i := 0; i < b.N; i++ {
		inbox[i] = tr
	}
}

func BenchmarkBatchIteration(b *testing.B) {
	b.StopTimer()
	inbox := newInbox()
	outbox := newInbox()
	for i := int64(0); i < 10000; i++ {
		t := &Transaction{code: i}
		t.Credit(i, "USD", 1)
		t.Debit(i+1, "USD", 1)
		inbox.Add(t)
	}

	nb := newBatcher(inbox, outbox, 4)
	deferred := make([]*Transaction, 0, 20)

	b.StartTimer()
	for i := 0; i < b.N; i = i + 2 {
		nb.iteration(deferred)
	}
}
