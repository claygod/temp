package accounter

// Accounter
// Batch
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import "log"
import "runtime"

// newBatcher - create new batch
func newBatcher(in *Queue, out *Queue, size int64, chanBatcher chan *Transaction, chanExecutor chan *batch) *batcher {
	b := &batcher{
		in:           in,
		out:          out,
		size:         size,
		chanBatcher:  chanBatcher,
		chanExecutor: chanExecutor,
	}
	return b
}

// batcher is a  ...
type batcher struct {
	chanBatcher  chan *Transaction
	chanExecutor chan *batch
	in           *Queue
	out          *Queue
	size         int64
	stop         bool
}

// start of a batcher
func (b *batcher) start() {
	deferred := make([]*Transaction, 0, 222)
	log.Print("----- start BATCHER --------")
	for {
		//log.Print("----- iterat --------")
		if b.stop {
			return
		}
		//b.iteration222(deferred, int(b.size))
		//runtime.Gosched()
		if res := b.iteration(deferred, int(b.size)); !res {
			//log.Print(res)
			runtime.Gosched()
		}
	}
}

func (b *batcher) iteration222(deferred []*Transaction, batchSize int) bool {
	var nb batch
	ns := 0 // new batch size
	lock := make(map[uint64]string)
	//log.Print("werwer 0000000000000000")
	for i := 0; i < batchSize; i++ {
		t, ok := b.in.PopHead()
		//
		if !ok || t == nil {
			//log.Print("werwer 11111111111111111")
			break
		}
		//log.Print("итератор получил транзакцию")
		b.addToBatch(&nb, t.(*Transaction), lock, ns)
	}
	b.out.PushTail(nb)
	return false
}

// iteration
func (b *batcher) iteration(deferred []*Transaction, batchSize int) bool {
	var nb batch
	ns := 0 // new batch size
	lock := make(map[uint64]string)

	for i := 0; i < len(deferred) && i < batchSize; i++ {
		if b.addToBatch(&nb, deferred[i], lock, ns) {
			deferred = append(deferred[:i], deferred[i+1:]...)
			ns++
		}
	}
	for ; ns < batchSize; ns++ {
		/*
		   select {
		   case msg := <-messages:
		       fmt.Println("received message", msg)
		   default:
		       fmt.Println("no message received")
		   }
		*/
		t, ok := b.in.PopHead()
		if !ok || t == nil {
			break
		}
		//log.Print(t)
		if !b.addToBatch(&nb, t.(*Transaction), lock, ns) {
			deferred = append(deferred, t.(*Transaction))
			ns--
		}
	}
	b.out.PushTail(nb)
	if ns != batchSize-1 {
		return false
	}
	return true
}

func (b *batcher) addToBatch(ba *batch, tr *Transaction, lock map[uint64]string, ns int) bool {
	lockLocal := make(map[uint64]string)

	for _, req := range tr.requests {
		_, ok := lock[req.hash]
		_, ok2 := lockLocal[req.hash]
		if ok || ok2 {
			return false
		}
		lockLocal[req.hash] = req.key
	}

	for k, v := range lockLocal {
		lock[k] = v
	}
	(*ba)[ns] = tr
	return true
}

// batch is a  ...
type batch [maxBatchSize]interface{}
