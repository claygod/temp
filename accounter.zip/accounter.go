package accounter

// Indicator
// API
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

//"errors"
//"log"
//"runtime"
//"sync/atomic"

const trialLimitConst int = 2147483647
const trialStop int = 64
const closed int64 = -2147483647
const maxBatchSize int64 = 64
const accStopped int64 = 4611686018427387904

var trialLimit int = trialLimitConst
var batchSize int64 = 32

// New - create new Accounter
func New(batchSize int64) *Accounter {
	gateBatcher := newQueue()
	gateExecutor := newQueue()
	a := &Accounter{
		b:  newBatcher(gateBatcher, gateExecutor, batchSize),
		e:  newExecutor(gateExecutor),
		gb: gateBatcher,
		ge: gateExecutor,
	}
	return a
}

// Accounter is a  ...
type Accounter struct {
	b  *batcher
	e  *executor
	gb *Queue
	ge *Queue
}

func (a *Accounter) Begin() *Transaction {
	return &Transaction{accounter: a}
}

func (a *Accounter) SetBatchSize(size int) *Transaction {
	return nil
}

func (a *Accounter) doTransaction(t *Transaction) *Transaction {
	return nil
}
