# accounter

[![API documentation](https://godoc.org/github.com/claygod/accounter?status.svg)](https://godoc.org/github.com/claygod/accounter)
[![Go Report Card](https://goreportcard.com/badge/github.com/claygod/accounter)](https://goreportcard.com/report/github.com/claygod/accounter)

Transactions and accounting of accounts.