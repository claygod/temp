package accounter

// Accounter
// Batcher test
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import (
	// "sync/atomic"
	"testing"
)

func TestBatcherXwe222(t *testing.T) {
	tr := &Transaction{tid: 111}
	tr.Credit(1, "USD", 1)
	tr.Debit(2, "USD", 1)

	nb := newBatcher(nil, nil, 4)
	//deferred := make([]*Transaction, 0, 22222)

	if nb.size == 150 {
		t.Error("Error ")
	}
}
