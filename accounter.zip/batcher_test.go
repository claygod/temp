package accounter

// Accounter
// Batcher test
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import (
	// "sync/atomic"
	"testing"
)

func TestBatcherXwe(t *testing.T) {
	inbox := newInbox()
	outbox := newInbox()
	tr := &Transaction{code: 111}
	tr.Credit(1, "USD", 1)
	tr.Debit(2, "USD", 1)
	inbox.Add(tr)

	nb := newBatcher(inbox, outbox, 4)
	//deferred := make([]*Transaction, 0, 22222)

	if nb.size == 150 {
		t.Error("Error ")
	}
}
