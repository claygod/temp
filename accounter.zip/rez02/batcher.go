package accounter

// Accounter
// Batch
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import (
	"runtime"
)

// newBatcher - create new batch
func newBatcher(in *Queue, out *Queue, size int) *batcher {
	b := &batcher{
		in:   in,
		out:  out,
		size: size,
	}
	return b
}

// batcher is a  ...
type batcher struct {
	in   *Queue
	out  *Queue
	size int
	stop bool
}

// start of a batcher
func (b *batcher) start() {
	deferred := make([]*Transaction, 0, 222)
	for {
		if b.stop {
			return
		}
		if !b.iteration(deferred, b.size) {
			runtime.Gosched()
		}
	}
}

// iteration
func (b *batcher) iteration(deferred []*Transaction, batchSize int) bool {
	var nb batch
	ns := 0 // new batch size
	lock := make(map[int64]string)

	for i := 0; i < len(deferred) && i < batchSize; i++ {
		if b.transactionInBatch(&nb, deferred[i], lock) {
			deferred = append(deferred[:i], deferred[i+1:]...)
			ns++
		}
	}
	for ; ns < batchSize; ns++ {
		t, ok := b.in.PopHead()
		if !ok || t == nil {
			break
		}
		if !b.transactionInBatch(&nb, t.(*Transaction), lock) {
			deferred = append(deferred, t.(*Transaction))
			ns--
		}
	}
	b.out.PushTail(nb)
	if ns != batchSize-1 {
		return false
	}
	return true
}

func (b *batcher) transactionInBatch(ba *batch, tr *Transaction, lock map[int64]string) bool {
	lockLocal := make(map[int64]string)
	for _, req := range tr.down {
		key, ok := lock[req.id]
		key2, ok2 := lockLocal[req.id]
		if ok && key == req.key ||
			ok2 && key2 == req.key {
			return false
		}
		lockLocal[req.id] = req.key
	}

	for k, v := range lockLocal {
		lock[k] = v
	}
	(*ba)[0] = tr
	return true
}

// batch is a  ...
type batch [maxBatchSize]interface{}
