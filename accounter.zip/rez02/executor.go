package accounter

// Accounter
// Executor
// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

import (
	"runtime"
)

// newExecutor - create new batch
func newExecutor(in *Queue, batchSize int) *executor {
	e := &executor{
		in: in,
		//batchSize: batchSize,
	}
	return e
}

// executor is a  ...
type executor struct {
	in    *Queue
	inbox *inbox
	stop  bool
}

// start of a executor
func (e *executor) start() {
	for {
		if e.stop {
			return
		}
		if !e.step() {
			runtime.Gosched()
		}
	}
}

// step
func (e *executor) step() bool {
	b, ok := e.in.PopHead()
	if !ok {
		return false
	}
	nb := b.(batch)
	for c, t := range nb {
		if t != nil {
			nt := t.(*Transaction)
			nt.tid = int64(c) // 222
		}
	}
	return true
}
