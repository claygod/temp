// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

package bxog

// Index

import (
	"log"
	"net/http"
	"strings"
)

// Router using the index selects the route
type index struct {
	tree  map[typeHash]*node
	tree2 *node
	index map[typeHash]route
}

func newIndex() *index {
	return &index{
		tree: make(map[typeHash]*node),
		//tree2: make(map[typeHash]*node),
		index: make(map[typeHash]route),
	}
}

func (x *index) find(req *http.Request) *route {
	//log.Print(req.URL)
	//log.Print(req.URL.Path)
	salt := x.genSalt(req.Method)
	cHashes := [HTTP_SECTION_COUNT]typeHash{}

	//return nil
	level := x.genUintSlice(req.URL.Path, salt, &cHashes) // req.URL.Path // 11111111111111
	var cNode *node

	if x.tree[cHashes[0]] != nil {
		cNode = x.tree[cHashes[0]]
	} else if x.tree[x.genUint(DELIMITER_STRING, salt)] != nil {
		cNode = x.tree[x.genUint(DELIMITER_STRING, salt)]
	} else {
		return nil
	}
	// slash
	if level == 0 {
		return cNode.route
	}

	for i := 0; i < level; i++ {
		if cNode.route == nil {
			if cNode.child[cHashes[i]] != nil {
				cNode = cNode.child[cHashes[i]]
			} else if cNode.child[DELIMITER_UINT] != nil {
				cNode = cNode.child[DELIMITER_UINT]
			} else {
				return nil
			}
		} else if i == level-1 {
			return cNode.route
		} else {
			return nil
		}
	}
	return nil
}

func (x *index) getNode(level int, arr map[string]*route) *node {
	out := newNode()
	//if len(arr) == level {
	//	return *out
	//}

	childs := make(map[typeHash]map[string]*route)
	for url, r := range arr {
		url = strings.Trim(url, DELIMITER_STRING)
		log.Print(" -URL- ", url)
		if url == "" {
			log.Print(" -keyC- ")
			out.route = r
			return out
		}
		arrStr := strings.Split(url, DELIMITER_STRING)
		if len(arrStr) > 1 {
			key := arrStr[0]
			log.Print(" -keyA- ", key, r.sections)
			salt := x.genSalt(r.method)
			//log.Print(" -salt- ", r.method)
			hash := x.genUint(key, salt)

			//sct := r.sections[len(r.sections)-len(arrStr):]
			//log.Print(" -sct- ", sct[0])
			if key[:1] == ":" { //  sct[0].typeSec == TYPE_ARG {
				hash = x.genUint(DELIMITER_STRING, salt)
			}
			//log.Print(" -hash- ", hash)
			if _, ok := childs[hash]; !ok {
				childs[hash] = make(map[string]*route)
			}
			arrStr = arrStr[1:]
			url = strings.Join(arrStr, DELIMITER_STRING)
			childs[hash][url] = r
		} else if len(arrStr) == 1 {
			key := arrStr[0]
			log.Print(" -keyB- ", key)
			salt := x.genSalt(r.method)
			hash := x.genUint(key, salt)

			//sct := r.sections[len(r.sections)-len(arrStr):]
			//log.Print(" -sct- ", sct[0])
			if key[:1] == ":" { //sct[0].typeSec == TYPE_ARG {
				hash = x.genUint(DELIMITER_STRING, salt)
			}
			//log.Print(" -hash- ", hash)
			if _, ok := childs[hash]; !ok {
				childs[hash] = make(map[string]*route)
			}
			arrStr = make([]string, 0)
			url = "" //trings.Join(arrStr, DELIMITER_STRING)╫
			childs[hash][url] = r
		}
	}
	for hash, v := range childs {
		n := x.getNode(level+1, v)
		out.child[hash] = n
	}
	//log.Print(" -возвращённая нода (без роута)- ", out)
	return out
}

func (x *index) compile2(routes []*route) {
	// вычисляем максимальное количество секций
	var maxSect int
	for _, r := range routes {
		log.Print(r.id, " --- ", len(r.sections))
		if len(r.sections) > maxSect {
			maxSect = len(r.sections)
		}
	}
	// формируем массив роутов, упорядоченный по числу секций
	mapRoutes := make(map[string]*route)
	arrRoutes := make([][]*route, maxSect+1)
	arrUnies := make([][]*uni, maxSect+1)
	for _, r := range routes {
		//log.Print(r.id, " --- ", len(r.sections))
		if arrRoutes[len(r.sections)] == nil {
			arrRoutes[len(r.sections)] = make([]*route, 0)
			arrUnies[len(r.sections)] = make([]*uni, 0)
		}
		mapRoutes[r.url] = r
		arrRoutes[len(r.sections)] = append(arrRoutes[len(r.sections)], r)
		un := &uni{url: r.url, route: r}
		arrUnies[len(r.sections)] = append(arrUnies[len(r.sections)], un)
	}
	x.tree2 = x.getNode(0, mapRoutes)
	// перебираем упорядоченные по количеству секций роуты
	arrNodes := make(map[string]*node)
	actualRoutes := make([][]*section, 0)
	for i := maxSect; i > 0; i-- {
		for _, r := range arrRoutes[i] { // тут конечные роуты
			n := newNode()
			n.route = r
			arrNodes[r.id] = n
			actualRoutes = append(actualRoutes, r.sections)
		}
		//for _, v := range actualRoutes {

		//}
	}
}

type uni struct {
	url      string
	sections []string
	route    *route
}

func (x *index) compile(routes []*route) {
	for _, route := range routes {
		salt := x.genSalt(route.method)
		x.index[x.genUint(route.id, 0)] = *route
		length := len(route.sections)
		cNode := newNode()
		// slash
		if length == 0 {
			cNode.route = route
			x.tree[SLASH_HASH] = cNode
			continue
		}
		cHash := x.genUint(route.sections[0].id, salt)
		if x.tree[cHash] != nil {
			cNode = x.tree[cHash]
		} else {
			switch route.sections[0].typeSec {
			case TYPE_STAT:
				x.tree[cHash] = cNode
			case TYPE_ARG:
				x.tree[x.genUint(DELIMITER_STRING, salt)] = cNode
			}
		}
		for i := 0; i < length; i++ {
			if i == length-1 {
				cNode.route = route
			} else {
				nNode := newNode()
				switch route.sections[i].typeSec {
				case TYPE_STAT:
					if i == 0 {
						cNode.child[x.genUint(route.sections[i].id, salt)] = nNode
					} else {
						cNode.child[x.genUint(route.sections[i].id, 0)] = nNode
					}
				case TYPE_ARG:
					if i == 0 {
						cNode.child[x.genUint(DELIMITER_STRING, salt)] = nNode
					} else {
						cNode.child[DELIMITER_UINT] = nNode
					}
				}
				cNode = nNode
			}
		}
	}
}

func (x *index) genUintSlice(s string, total typeHash, cHashes *[HTTP_SECTION_COUNT]typeHash) int {
	c := DELIMITER_BYTE
	na := 0
	length := len(s)
	if length == 1 {
		cHashes[0] = SLASH_HASH
		return 0
	}

	for i := 1; i < length; i++ {
		if s[i] == c {
			cHashes[na] = total
			total = 0
			na++
			continue
		}
		total = total<<5 + typeHash(s[i])
	}
	cHashes[na] = total
	na++
	return na
}

func (x *index) genUint(s string, total typeHash) typeHash {
	length := len(s)
	for i := 0; i < length; i++ {
		total = total<<5 + typeHash(s[i])
	}
	return total
}

func (x *index) genSalt(s string) typeHash {
	return typeHash(s[0] + s[1])
}
