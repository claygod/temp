// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

package bxog

// Index

import (
	//"log"
	"net/http"
	"strings"
)

// Router using the index selects the route
type index struct {
	//tree  map[typeHash]*node
	tree2 node2
	core  *route
	index map[typeHash]route
}

func newIndex() *index {
	return &index{
		//tree: make(map[typeHash]*node),
		//tree2: make(map[typeHash]*node),
		index: make(map[typeHash]route),
	}
}

func (x *index) find2(req *http.Request) *route {

	if req.URL.Path == "/" {
		return x.core
	}
	salt := x.genSalt(req.Method)
	cHashes := [HTTP_SECTION_COUNT]typeHash{}
	level := x.genUintSlice2(req.URL.Path, salt, &cHashes)
	//log.Print("__--__ Надыбали черезе findX: ", x.findX(level, 0, x.tree2, cHashes))
	return x.findX(level, 0, x.tree2, &cHashes)
	if level == 112 {
		//log.Print("На 1002 отправляем: ", req.URL.Path, " ", cHashes)
		return x.find1002(cHashes)
	}
	//log.Print("Набор хэшей (искомых): ", cHashes)
	cNode := x.tree2
	for i := 0; i <= level; i++ {
		//log.Print(" ----------- ", cHashes[i], " ", cNode.child)
		if cNode.flag == false {
			if _, ok := cNode.child[cHashes[i]]; ok {
				//log.Print(" ----------- A ")
				cNode = cNode.child[cHashes[i]]

			} else if _, ok := cNode.child[DELIMITER_UINT]; ok {
				cNode = cNode.child[DELIMITER_UINT]
				//log.Print(" ----------- B ")
			} else {
				//log.Print(" ----------- C ")
				return nil
			}
		} else if i == level {
			//log.Print(" ----------- D ")
			return cNode.route
		} else {
			//log.Print(" ----------- E ")
			return nil
		}
	}
	return nil
}

func (x *index) find1002(cHashes [HTTP_SECTION_COUNT]typeHash) *route {
	if z, ok := x.tree2.child[cHashes[0]]; ok {
		if z10, ok := z.child[cHashes[1]]; ok {
			return z10.route
		} else if z11, ok := z.child[DELIMITER_UINT]; ok {
			return z11.route
		}
	} else {
		if z20, ok := x.tree2.child[DELIMITER_UINT].child[cHashes[1]]; ok {
			return z20.route
		} else if z21, ok := z20.child[DELIMITER_UINT]; ok {
			return z21.child[DELIMITER_UINT].route
		}
	}
	return nil
}

func (x *index) findX(ln int, level int, tree2 node2, cHashes *[HTTP_SECTION_COUNT]typeHash) *route {
	if ln == level {

		//log.Print(" ----------- C1 ")
		return tree2.route
		/*
			if z1, ok := tree2.child[cHashes[level]]; ok {
				log.Print(" ----------- C2 ")
				return z1.route
			} else if z2, ok := tree2.child[DELIMITER_UINT]; ok {
				log.Print(" ----------- C3 ")
				return z2.route
			}
			log.Print(" ----------- C4 ")
			return nil
		*/
	} else if z1, ok := tree2.child[cHashes[level]]; ok {
		//log.Print(" ----------- C5 ")
		return x.findX(ln, level+1, z1, cHashes)
	} else if z2, ok := tree2.child[DELIMITER_UINT]; ok {
		//log.Print(" ----------- C6 ", level, ln)
		return x.findX(ln, level+1, z2, cHashes)
	}
	//log.Print(" ----------- C7 ")
	return nil
}

func (x *index) find1003(cHashes [HTTP_SECTION_COUNT]typeHash) *route {
	if z1, ok := x.tree2.child[cHashes[0]]; ok {
		if z10, ok := z1.child[cHashes[1]]; ok {
			if z100, ok := z10.child[cHashes[2]]; ok {
				return z100.route
			} else if z110, ok := z10.child[DELIMITER_UINT]; ok {
				return z110.route
			}
		} else if z11, ok := z1.child[DELIMITER_UINT]; ok {
			if z110, ok := z11.child[cHashes[2]]; ok {
				return z110.route
			} else if z110, ok := z11.child[DELIMITER_UINT]; ok {
				return z110.route
			}
		}
	} else {
		if z20, ok := x.tree2.child[DELIMITER_UINT].child[cHashes[1]]; ok {
			return z20.route
		} else if z21, ok := z20.child[DELIMITER_UINT]; ok {
			return z21.child[DELIMITER_UINT].route
		}
	}
	return nil
}

func (x *index) getNode(arr map[string]*route) node2 {
	out := newNode2()
	childs := make(map[typeHash]map[string]*route)
	for url, r := range arr {
		url = strings.Trim(url, DELIMITER_STRING)
		//log.Print(" -URL- ", url)
		if url == "" {
			//log.Print(" -keyC- ")
			out.route = r
			out.flag = true
			return out
		}
		arrStr := strings.Split(url, DELIMITER_STRING)
		if len(arrStr) > 1 {
			key := arrStr[0]
			salt := x.genSalt(r.method)
			hash := x.genUint(key, salt)
			if key[:1] == ":" { //  sct[0].typeSec == TYPE_ARG {
				hash = DELIMITER_UINT //x.genUint(DELIMITER_STRING, salt)
			}
			//log.Print(" -keyA- ", key, " ", hash)
			if _, ok := childs[hash]; !ok {
				childs[hash] = make(map[string]*route)
			}
			arrStr = arrStr[1:]
			url = strings.Join(arrStr, DELIMITER_STRING)
			childs[hash][url] = r
		} else if len(arrStr) == 1 {
			key := arrStr[0]

			salt := x.genSalt(r.method)
			hash := x.genUint(key, salt)
			//log.Print(" -sct- ", sct[0])
			if key[:1] == ":" { //sct[0].typeSec == TYPE_ARG {
				hash = DELIMITER_UINT //x.genUint(DELIMITER_STRING, salt)
			}
			//log.Print(" -keyB- ", key, " ", hash)
			if _, ok := childs[hash]; !ok {
				childs[hash] = make(map[string]*route)
			}
			arrStr = make([]string, 0)
			url = "" //trings.Join(arrStr, DELIMITER_STRING)╫
			childs[hash][url] = r
		}
	}
	for hash, v := range childs {
		n := x.getNode(v)
		out.child[hash] = n
	}
	return out
}

func (x *index) compile2(routes []*route) {
	mapRoutes := make(map[string]*route)
	for _, r := range routes {
		x.index[x.genUint(r.id, 0)] = *r
		if r.url == "/" {
			x.core = r
		} else {
			mapRoutes[r.url] = r
		}
	}
	x.tree2 = x.getNode(mapRoutes)
}

func (x *index) genUintSlice2(s string, salt typeHash, cHashes *[HTTP_SECTION_COUNT]typeHash) int {
	c := DELIMITER_BYTE
	na := 0
	length := len(s)
	if length == 1 {
		cHashes[0] = SLASH_HASH
		return 0
	}
	var total typeHash = salt
	for i := 1; i < length; i++ {
		if s[i] == c {
			cHashes[na] = total
			total = salt
			na++
			continue
		}
		total = total<<5 + typeHash(s[i])
	}
	cHashes[na] = total
	na++
	return na
}

func (x *index) genUint(s string, total typeHash) typeHash {
	//var total typeHash = 0
	length := len(s)
	for i := 0; i < length; i++ {
		total = total<<5 + typeHash(s[i])
	}
	return total
}

func (x *index) genSalt(s string) typeHash {
	return typeHash(s[0] + s[1])
}
