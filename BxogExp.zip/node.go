// Copyright © 2016 Eduard Sesigin. All rights reserved. Contacts: <claygod@yandex.ru>

package bxog

// Node

// Nodes are stored in the index. Used for route search.
/*
type node struct {
	child map[typeHash]*node
	route *route
}

func newNode() *node {
	nNode := &node{}
	nNode.child = make(map[typeHash]*node)
	return nNode
}
*/
// Nodes are stored in the index. Used for route search.
type node2 struct {
	child map[typeHash]node2
	route *route
	flag  bool
}

func newNode2() node2 {
	nNode := node2{}
	nNode.child = make(map[typeHash]node2)
	return nNode
}
